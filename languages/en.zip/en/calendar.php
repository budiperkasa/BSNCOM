<?php

$language['LANG_CALENDAR_SETTINGS_MENU'] = "Calendar widget settings";
$language['LANG_CALENDAR_SETTINGS_TITLE'] = "Calendar widget settings";
$language['LANG_CALENDAR_NAME'] = "Calendar widget name";
$language['LANG_CALENDAR_ANY_TYPE'] = "Any type";
$language['LANG_CALENDAR_TYPE'] = "Connected type";
$language['LANG_CALENDAR_FIELD'] = "Connected content field";
$language['LANG_CALENDAR_SEARCH_BY_CREATION_DATE'] = "Creation date";
$language['LANG_CALENDAR_VISIBILITY_INDEX'] = "Widget visible on index page";
$language['LANG_VISIBILE'] = "visible";
$language['LANG_NOT_VISIBILE'] = "not visible";
$language['LANG_CALENDAR_VISIBILITY_FOR_TYPES'] = "Widget visible for types";
$language['LANG_CALENDAR_VISIBILITY_FOR_ALL_TYPES'] = "for any type";
$language['LANG_CALENDAR_VISIBILITY_FOR_CONNECTED_TYPE'] = "only for connected type";
$language['LANG_CALENDAR_SAVE_SUCCESS'] = "Calendar settings were successfully saved!";
?>