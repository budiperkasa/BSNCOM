<?php

$language['LANG_RSS_FEED_RECENT_LISTINGS'] = "Feed recent listings";
$language['LANG_RSS_FEED_TYPE_LISTINGS'] = "Feed listings of this type";
$language['LANG_RSS_FEED_CATEGORIES_LISTINGS'] = "Feed listings of this category";
$language['LANG_RSS_FEED_SEARCH_LISTINGS'] = "Feed listings of this search results";
$language['LANG_RSS_FEED_IN_LOCATION'] = "in location";
?>