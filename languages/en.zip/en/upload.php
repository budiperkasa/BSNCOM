<?php
	
/**
 * Images upload block
 */
$language['LANG_MAX_IMAGE_SIZE'] = "Max image size";
$language['LANG_MAX_FILE_SIZE'] = "max file size";
$language['LANG_NEW_FILE_TITLE'] = "New file title";
$language['LANG_SYMBOLS_MAX'] = "symbols max";
$language['LANG_BUTTON_UPLOAD_FILE'] = "Upload file";
$language['LANG_UPLOAD_FILE'] = "Upload new file";
$language['LANG_UPLOAD_IMAGE'] = "Upload new image";
$language['LANG_SUPPORTED_FORMAT'] = "Supported formats";
$language['LANG_BUTTON_UPLOAD_IMAGE'] = "Upload image";
$language['LANG_CROP_IMAGE'] = "Crop image";
?>