<?php

$language['LANG_FACEBOOK_LOGIN_BTN'] = "Facebook Login";
$language['LANG_FACEBOOK_SETTINGS'] = "Facebook Settings";
$language['LANG_FACEBOOK_API_KEY'] = "Facebook API Key";
$language['LANG_FACEBOOK_APP_ID'] = "Facebook Application ID";
$language['LANG_FACEBOOK_API_KEY_SIGNUP'] = "<a href='http://www.facebook.com/developers/createapp.php' target='_blank'>Register</a> your Facebook Application";
$language['LANG_FACEBOOK_APP_SECRET'] = "Facebook Application Secret word";
?>