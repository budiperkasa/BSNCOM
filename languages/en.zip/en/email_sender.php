<?php
	
	

$language['LANG_SEND_EMAIL_MESSAGE_TITLE'] = "Send email message";
$language['LANG_MESSAGE_FROM'] = "Message from";
$language['LANG_YOUR_NAME'] = "Your name";
$language['LANG_YOUR_EMAIL'] = "Your email";
$language['LANG_MESSAGE_TO'] = "Message to";
$language['LANG_RECIPIENT_NAME'] = "Recipient name";
$language['LANG_RECIPIENT_EMAIL'] = "Recipient email";
$language['LANG_SEND_SUCCESS'] = "Email message was sent successfully!";
$language['LANG_SUBJECT'] = "Subject";
$language['LANG_MESSAGE'] = "Message";
$language['LANG_BUTTON_SEND'] = "Send";
$language['LANG_BUTTON_CLOSE'] = "Close";
$language['LANG_CAPTCHA'] = "Captcha field";

$language['LANG_EMAIL_FRIEND_SUBJ'] = "Here is information on";
$language['LANG_EMAIL_OWNER_SUBJ'] = "According to your listing";
$language['LANG_EMAIL_REPORT_SUBJ'] = "Report about listing";
?>