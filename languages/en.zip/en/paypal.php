<?php
	

$language['LANG_PAYPAL_SETTINGS'] = "PayPal settings";
$language['LANG_PAYPAL_REDIRECT_TITLE'] = "You will be redirected to PayPal";
$language['LANG_PAYPAL_REDIRECT_MANUAL'] = "If you are not automatically redirected to PayPal within 5 seconds...";
$language['LANG_PAYPAL_EMAIL'] = "PayPal Business Email";
?>