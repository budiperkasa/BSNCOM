<?php

$language['LANG_MAP'] = "Google Map";

$language['LANG_BUTTON_MAP'] = "Generate on google map";
$language['LANG_ENTER_LTLG_MANUALLY'] = "Enter manually Latitude/Longitude";
$language['LANG_HIDE_LTLG_MANUALLY'] = "Geocode Latitude/Longitude from address";
$language['LANG_MAP_LATITUDE'] = "Google map latitude";
$language['LANG_MAP_LONGITUDE'] = "Google map longitude";
$language['LANG_MAP_POINT_ADDRESS'] = "Google map point address";
$language['LANG_MAP_ZOOM_LEVEL'] = "Google map zoom level";

$language['LANG_SELECT_ICON_LISTING'] = "Select icon and save listing";
$language['LANG_SELECT_ICON_LISTING_NOTE'] = "NOTE: Icons set depends on selected categories";
$language['LANG_RESET_ICON'] = "Reset icon";
$language['LANG_BUTTON_MARKER_ICON'] = "Select marker icon";
$language['LANG_MAP_ICON_ID'] = "Map marker icon ID";
$language['LANG_MAP_ICON_FILE'] = "Map marker icon file";
?>