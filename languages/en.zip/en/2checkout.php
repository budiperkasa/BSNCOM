<?php

$language['LANG_2CHECKOUT_REDIRECT_TITLE'] = "You will be redirected to 2Checkout";
$language['LANG_2CHECKOUT_REDIRECT_MANUAL'] = "If you are not automatically redirected to 2Checkout within 5 seconds...";
$language['LANG_2CHECKOUT_SID'] = "2CheckOut sid";
$language['LANG_2CHECKOUT_SWORD'] = "2CheckOut secret word";
$language['LANG_2CHECKOUT_SWORD_DESCR'] = "Login into your 2checkout.com account and go to 'Look and Feel' section. At the bottom enter the Secret Word and use it in the IPN verification process.";
$language['LANG_2CHECKOUT_SETTINGS'] = "2CheckOut settings";
?>