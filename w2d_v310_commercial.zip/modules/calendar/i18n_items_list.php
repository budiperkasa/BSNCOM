<?php
$i18n_fields['calendar_settings'][] = 'name';
?>