DROP TABLE `invoices`;
DROP TABLE `transactions`;
DROP TABLE `payment_gateways`;
DROP TABLE `listings_price`;
DROP TABLE `listings_payment_upgrades`;