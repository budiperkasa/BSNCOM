DROP TABLE `categories`;

DROP TABLE `map_marker_icons_themes`;
DROP TABLE `map_marker_icons`;