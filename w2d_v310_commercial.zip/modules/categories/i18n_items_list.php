<?php
$i18n_fields['categories'][] = 'name';
$i18n_fields['categories'][] = 'meta_title';
$i18n_fields['categories'][] = 'meta_description';
$i18n_fields['map_marker_icons_themes'][] = 'name';
$i18n_fields['map_marker_icons'][] = 'name';
?>