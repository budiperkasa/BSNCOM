<?php

class translation_db_static_vars
{
	public static $i18n_fields = array();
	public static $tables = array();
	public static $selects = array();
	public static $wheres = array();
	public static $likes = array();
	public static $sets = array();
	public static $insert_tables = array();
	
	
}
?>