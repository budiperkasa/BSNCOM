INSERT INTO `payment_gateways` (`gateway`, `module`) VALUES ('AlertPay', 'alertpay');

INSERT INTO `system_settings` (`name`, `value`) VALUES ('alertpay_email', '');
INSERT INTO `system_settings` (`name`, `value`) VALUES ('alertpay_securitycode', '');