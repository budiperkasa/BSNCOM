DROP TABLE `locations`;
DROP TABLE `locations_levels`;