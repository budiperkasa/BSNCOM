<?php
$i18n_fields['locations_levels'][] = 'name';
$i18n_fields['locations'][] = 'name';
?>