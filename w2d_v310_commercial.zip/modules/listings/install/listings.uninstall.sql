DROP TABLE `listings`;
DROP TABLE `listings_fields_visibility`;
DROP TABLE `listings_in_categories`;
DROP TABLE `files`;
DROP TABLE `images`;
DROP TABLE `videos`;