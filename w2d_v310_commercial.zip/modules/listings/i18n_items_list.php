<?php
$i18n_fields['listings'][] = 'title';
$i18n_fields['listings'][] = 'listing_description';
$i18n_fields['listings'][] = 'listing_meta_description';
$i18n_fields['listings'][] = 'listing_keywords';

$i18n_fields['listings_in_locations'][] = 'location';
$i18n_fields['listings_in_locations'][] = 'address_line_1';
$i18n_fields['listings_in_locations'][] = 'address_line_2';

$i18n_fields['images'][] = 'title';
$i18n_fields['videos'][] = 'title';
$i18n_fields['files'][] = 'title';
?>