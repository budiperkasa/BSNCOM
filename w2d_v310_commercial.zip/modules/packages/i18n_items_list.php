<?php
$i18n_fields['packages'][] = 'name';
?>