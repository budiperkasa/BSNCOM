<?php
$i18n_fields['content_pages'][] = 'title';
?>