DROP TABLE `modules`;
DROP TABLE `themes`;
DROP TABLE `language_files`;