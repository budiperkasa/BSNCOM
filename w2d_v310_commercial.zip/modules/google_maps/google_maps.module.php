<?php
class google_mapsModule
{
	public $title = "Google Maps";
	public $version = "0.2";
	public $description = "Google maps management module";
	public $type = "core";
	public $lang_files = "google_maps.php";

	//  ABQIAAAAKYGrlIpQ-tDNDjL2glW9WRS6irw07YFj3-p7C6OmjF6BZFhgpBQi8U-SQipMI36FLPtZeLShH2DU1g
	//  ABQIAAAAKYGrlIpQ-tDNDjL2glW9WRRW1dGG-MfNAglHtSQluwJ9xIASKBQhtAyXxT6A_OLwNYLySMf_6EPsiQ

}
?>