<?php
$i18n_fields['discount_coupons'][] = 'description';
?>