<?php
$i18n_fields['banners_blocks'][] = 'name';
?>