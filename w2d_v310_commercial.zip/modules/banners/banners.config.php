<?php

$config['users_content'] = array(
	'banner_file' => array(
		'upload_to' => 'banners/',
		'allowed_types' => 'jpg|gif|png|swf',
	),
);
?>