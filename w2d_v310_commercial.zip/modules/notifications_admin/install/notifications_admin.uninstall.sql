DELETE FROM `email_notification_templates` WHERE `event` = 'Listing creation Admin notification';
DELETE FROM `email_notification_templates` WHERE `event` = 'Account creation Admin notification';