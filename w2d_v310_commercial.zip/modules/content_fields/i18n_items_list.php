<?php
$i18n_fields['content_fields'][] = 'name';
$i18n_fields['content_fields'][] = 'frontend_name';
$i18n_fields['content_fields'][] = 'description';

$i18n_fields['content_fields_type_select'][] = 'option_name';
$i18n_fields['content_fields_type_checkboxes'][] = 'option_name';
$i18n_fields['content_fields_type_richtext_data'][] = 'field_value';
$i18n_fields['content_fields_type_varchar_data'][] = 'field_value';
$i18n_fields['content_fields_type_text_data'][] = 'field_value';
?>