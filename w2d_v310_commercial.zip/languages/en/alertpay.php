<?php
	

$language['LANG_ALERTPAY_SETTINGS'] = "AlertPay settings";
$language['LANG_ALERTPAY_REDIRECT_TITLE'] = "You will be redirected to AlertPay";
$language['LANG_ALERTPAY_REDIRECT_MANUAL'] = "If you are not automatically redirected to AlertPay within 5 seconds...";
$language['LANG_ALERTPAY_EMAIL'] = "AlertPay Business Email";
$language['LANG_ALERTPAY_SECURITYCODE'] = "AlertPay Security code.";
$language['LANG_ALERTPAY_SECURITYCODE_DESCR'] = "Should be used to confirm that the IPN received came from AlertPay. Compare it to the IPN Security Code in your AlertPay account.";
?>