<?php

$language['LANG_JSADVERTISEMENT_MANAGE_BLOCKS_TITLE'] = "Manage Javascript Advertisement blocks";
$language['LANG_JSADVERTISEMENT_ALL_BLOCKS'] = "Manage Javascript Advertisement blocks";
$language['LANG_CREATE_JSADVERTISEMENT_BLOCK'] = "create new js advertisement block";
$language['LANG_EDIT_JSADVERTISEMENT_BLOCK'] = "edit js advertisement block";
$language['LANG_CREATE_JSADVERTISEMENT'] = "Create new advertisement block";
$language['LANG_EDIT_JSADVERTISEMENT'] = "Edit js advertisement block";
$language['LANG_DELETE_JSADVERTISEMENT_BLOCK'] = "delete js advertisement block";
$language['LANG_JSADVERTISEMENT_BLOCK_NAME_TH'] = "Block name";
$language['LANG_JSADVERTISEMENT_BLOCK_MODE_TH'] = "View mode";
$language['LANG_JSADVERTISEMENT_BLOCK_SELECTOR_TH'] = "Selector";
$language['LANG_JSADVERTISEMENT_CODE'] = "Javascript Advertisement code";
$language['LANG_BUTTON_CREATE_JSADVERTISEMENT'] = "Create js advertisement block";
$language['LANG_DELETE_JSADVERTISEMENT'] = "Delete js advertisement block";
$language['LANG_DELETE_JSADVERTISEMENT_QUEST'] = "Do you really want to delete Javascript Advertisement block?";

$language['LANG_JSADVERTISEMENT_CREATE_TITLE'] = "Javascript Advertisement create new block";
$language['LANG_JSADVERTISEMENT_EDIT_TITLE'] = "Javascript Advertisement edit block";
$language['LANG_JSADVERTISEMENT_DELETE_TITLE'] = "Javascript Advertisement delete block";
$language['LANG_JSADVERTISEMENT_SETTINGS_MENU'] = "JS Advertisement settings";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_1'] = "Javascript Advertisement block";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_2'] = "was created successfully!";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_1'] = "Javascript Advertisement block";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_2'] = "was saved successfully!";
$language['LANG_JSADVERTISEMENT_DELETE_SUCCESS'] = "Javascript Advertisement block was deleted successfully!";
?>