<?php

$language['LANG_EMAIL_NOTIFICATIONS'] = "Edit email notification";
$language['LANG_NOTIFICATION_RAISE'] = "Notification raises on";
$language['LANG_NOTIFICATION_SUBJECT'] = "Notification subject";
$language['LANG_NOTIFICATION_BODY'] = "Notification body";
$language['LANG_VIEW_EMAIL_NOTIFICATIONS'] = "View email notifications";
$language['LANG_EDIT_NOTIFICATION_OPTION'] = "edit notification";
// Controller constants
$language['LANG_VIEW_EMAIL_NOTIFICATIONS_TITLE'] = "View email notifications";
$language['LANG_EDIT_EMAIL_NOTIFICATIONS_TITLE'] = "Edit email notifications";
$language['LANG_EMAIL_NOTIFICATIONS_MENU'] = "Email notifications";
$language['LANG_NOTIFICATION_SEND_SUCCESS_1'] = "Notification on event";
$language['LANG_NOTIFICATION_SEND_SUCCESS_2'] = "was saved successfully!";
?>