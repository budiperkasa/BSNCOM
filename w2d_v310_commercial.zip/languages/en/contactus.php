<?php

$language['LANG_CONTACTUS_LINK'] = "Contact us";
$language['LANG_CONTACT_US_TITLE'] = "Contact us";
$language['LANG_CONTACTUS_NAME'] = "Your name";
$language['LANG_CONTACTUS_EMAIL'] = "Your email";
$language['LANG_CONTACTUS_SUBJECT'] = "Message subject";
$language['LANG_CONTACTUS_BODY'] = "Message body";
$language['LANG_CONTACTUS_SEND_BUTTON'] = "Send";

$language['LANG_CONTACTUS_SUCCESS'] = "Message was sent successfully!";
$language['LANG_ENABLE_CONTACTUS_PAGE'] = "Enable contact us page";
?>