<?php
	

$language['LANG_PAYPAL_SETTINGS'] = "configurações PayPal";
$language['LANG_PAYPAL_REDIRECT_TITLE'] = "Você será redirecionado para o PayPal";
$language['LANG_PAYPAL_REDIRECT_MANUAL'] = "Se você não for automaticamente redirecionado para o PayPal dentro de 5 segundos ...";
$language['LANG_PAYPAL_EMAIL'] = "E-mail do PayPal Business";
?>