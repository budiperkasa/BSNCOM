<?php
	
/**
 * Images upload block
 */
$language['LANG_MAX_IMAGE_SIZE'] = "Tamanho máximo da imagem";
$language['LANG_MAX_FILE_SIZE'] = "tamanho máximo de arquivo";
$language['LANG_NEW_FILE_TITLE'] = "Novo título do arquivo";
$language['LANG_SYMBOLS_MAX'] = "max símbolos";
$language['LANG_BUTTON_UPLOAD_FILE'] = "Carregar arquivo";
$language['LANG_UPLOAD_FILE'] = "Carregar um arquivo novo";
$language['LANG_UPLOAD_IMAGE'] = "Upload de nova imagem";
$language['LANG_SUPPORTED_FORMAT'] = "Os formatos suportados";
$language['LANG_BUTTON_UPLOAD_IMAGE'] = "Enviar imagem";
$language['LANG_CROP_IMAGE'] = "Cortar uma imagem";
?>