<?php

$language['LANG_INSTALL_STEP1_TITLE'] = "Criar um utilizador do sistema radicular";
$language['LANG_INSTALL_STEP1_SUBTITLE'] = "usuário root tem privilégios de acesso global. Pode adicionar / editar / excluir grupos de usuários e permissões de grupos de usuários.";
$language['LANG_INSTALL_TITLE'] = "instalação do Sistema";
$language['LANG_INSTALL_USER_LOGIN'] = "Raiz de login do usuário";
$language['LANG_INSTALL_USER_EMAIL'] = "Raiz e-mail do usuário";
$language['LANG_INSTALL_USER_PASSWORD'] = "Senha";
$language['LANG_INSTALL_USER_PASSWORD_REPEAT'] = "Repita senha";
$language['LANG_INSTALL_BUTTON'] = "Continue a instalação";
$language['LANG_INSTALL_STEP2_TITLE'] = "Defina as configurações de site";
$language['LANG_INSTALL_WEBSITE_TITLE'] = "Website título";
$language['LANG_INSTALL_WEBSITE_EMAIL'] = "sistema de e-mail Website";
$language['LANG_INSTALL_FINISH_BUTTON'] = "A instalação completa";
$language['LANG_INSTALL_STEP3_TITLE'] = "A instalação foi processado com sucesso!";
$language['LANG_INSTALL_STEP3_SUBTITLE'] = "tabelas de banco de dados, o usuário root, configurações do site foi instalado com sucesso. Agora vá para a área de administração e instalação de módulos adicionais, preencha outras configurações do sistema. Antes que você pode criar o seu anúncio em primeiro lugar, você tem que criar tipos e níveis de anúncios, também gerenciar as categorias e localizações. Olhe através de campos de conteúdo e grupos de campos de conteúdo.";
?>