<?php

$language['LANG_2CHECKOUT_REDIRECT_TITLE'] = "Você será redirecionado para 2Checkout";
$language['LANG_2CHECKOUT_REDIRECT_MANUAL'] = "Se você não for automaticamente redirecionado para 2Checkout dentro de 5 segundos ...";
$language['LANG_2CHECKOUT_SID'] = "2CheckOut sid";
$language['LANG_2CHECKOUT_SWORD'] = "2CheckOut palavra secreta";
$language['LANG_2CHECKOUT_SWORD_DESCR'] = "Entrar na sua conta 2checkout.com e ir para o &#39;look and feel&#39; seção. Na parte inferior digite a palavra secreta e usá-lo no processo de verificação IPN.";
$language['LANG_2CHECKOUT_SETTINGS'] = "configurações 2CheckOut";
?>