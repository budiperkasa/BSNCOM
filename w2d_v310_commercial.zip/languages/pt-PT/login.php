<?php
	
	
/**
 * Authorization page
 */
$language['LANG_AUTHORIZATION_MENU'] = "Autorização";
$language['LANG_USER_EMAIL'] = "E-mail";
$language['LANG_USER_PASSWORD'] = "Usuário Senha";
$language['LANG_USER_LOGIN_ERROR'] = "E-mail ou senha está incorreta!";
$language['LANG_USER_BLOCKED'] = "Usuário com e-mail como foi bloqueada pelo administrador!";
/**
 * Login page, login block
 */
$language['LANG_LOGIN_HEADER'] = "Login";
$language['LANG_LOGIN_EMAIL'] = "E-mail";
$language['LANG_LOGIN_PASSWORD'] = "Senha";
$language['LANG_BUTTON_LOGIN'] = "Entrar";
$language['LANG_CREATE_ACCOUNT'] = "Crie uma conta";
$language['LANG_FORGOT_PASS'] = "Esqueceu a senha?";
$language['LANG_REMEMBER_ME'] = "Lembrar de mim";
?>