<?php

$language['LANG_EMAIL_NOTIFICATIONS'] = "Editar notificação por email";
$language['LANG_NOTIFICATION_RAISE'] = "Notificação coloca em";
$language['LANG_NOTIFICATION_SUBJECT'] = "objecto de notificação";
$language['LANG_NOTIFICATION_BODY'] = "corpo Notificação";
$language['LANG_VIEW_EMAIL_NOTIFICATIONS'] = "Exibir e-mail notificações";
$language['LANG_EDIT_NOTIFICATION_OPTION'] = "editar notificação";
// Controller constants
$language['LANG_VIEW_EMAIL_NOTIFICATIONS_TITLE'] = "Exibir e-mail notificações";
$language['LANG_EDIT_EMAIL_NOTIFICATIONS_TITLE'] = "Editar notificações de e-mail";
$language['LANG_EMAIL_NOTIFICATIONS_MENU'] = "E-mail notificações";
$language['LANG_NOTIFICATION_SEND_SUCCESS_1'] = "Notificação de evento";
$language['LANG_NOTIFICATION_SEND_SUCCESS_2'] = "foi salva com sucesso!";
?>