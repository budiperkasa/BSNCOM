<?php

$language['LANG_MAP'] = "Google Map";
$language['LANG_MAPS_SIGNUP'] = "<a href='http://code.google.com/apis/maps/signup.html' target='_blank'>Cadastre-se</a> para o Google Maps API key";
$language['LANG_MAPS_KEY'] = "Chave da API do Google Maps";

$language['LANG_BUTTON_MAP'] = "Gerar no mapa do google";
$language['LANG_ENTER_LTLG_MANUALLY'] = "Digite manualmente Latitude / Longitude";
$language['LANG_HIDE_LTLG_MANUALLY'] = "Geocode latitude / longitude a partir do endereço";
$language['LANG_MAP_LATITUDE'] = "Google Latitude mapa";
$language['LANG_MAP_LONGITUDE'] = "Google longitude mapa";
$language['LANG_MAP_POINT_ADDRESS'] = "Google endereço ponto do mapa";
$language['LANG_MAP_ZOOM_LEVEL'] = "mapa do Google nível de zoom";

$language['LANG_SELECT_ICON_LISTING'] = "Selecione o ícone e salvar anúncio";
$language['LANG_SELECT_ICON_LISTING_NOTE'] = "NOTA: Definir ícones depende categorias selecionadas";
$language['LANG_RESET_ICON'] = "ícone Reset";
$language['LANG_BUTTON_MARKER_ICON'] = "Selecione o ícone do marcador";
$language['LANG_MAP_ICON_ID'] = "Mapa marcador ícone ID";
$language['LANG_MAP_ICON_FILE'] = "Mapa do arquivo de ícone do marcador";
?>