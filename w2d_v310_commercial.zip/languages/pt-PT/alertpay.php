<?php

$language['LANG_ALERTPAY_SETTINGS'] = "AlertPay configurações";
$language['LANG_ALERTPAY_REDIRECT_TITLE'] = "Você será redirecionado para AlertPay";
$language['LANG_ALERTPAY_REDIRECT_MANUAL'] = "Se você não for redirecionado automaticamente para AlertPay dentro de 5 segundos ...";
$language['LANG_ALERTPAY_EMAIL'] = "Email AlertPay Negócios";
$language['LANG_ALERTPAY_SECURITYCODE'] = "Código de segurança AlertPay.";
$language['LANG_ALERTPAY_SECURITYCODE_DESCR'] = "deve ser usado para confirmar que o IPN recebeu veio do AlertPay Compare isso com o Código de Segurança IPN na sua conta AlertPay.";
?>