<?php

$language['LANG_SITEMAP_LINK'] = "Mapa do Site";
$language['LANG_SITEMAP_TITLE'] = "Mapa do Site";
?>