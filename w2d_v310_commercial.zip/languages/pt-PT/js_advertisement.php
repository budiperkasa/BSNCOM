<?php

$language['LANG_JSADVERTISEMENT_MANAGE_BLOCKS_TITLE'] = "Gerir blocos Javascript Anúncio";
$language['LANG_JSADVERTISEMENT_ALL_BLOCKS'] = "Gerir blocos Javascript Anúncio";
$language['LANG_CREATE_JSADVERTISEMENT_BLOCK'] = "criar o bloco novo anúncio js";
$language['LANG_EDIT_JSADVERTISEMENT_BLOCK'] = "js editar bloco de anúncio";
$language['LANG_CREATE_JSADVERTISEMENT'] = "Criar um bloco novo anúncio";
$language['LANG_EDIT_JSADVERTISEMENT'] = "Editar js bloco de anúncio";
$language['LANG_DELETE_JSADVERTISEMENT_BLOCK'] = "js excluir bloco de anúncio";
$language['LANG_JSADVERTISEMENT_BLOCK_NAME_TH'] = "nome do bloco";
$language['LANG_JSADVERTISEMENT_BLOCK_MODE_TH'] = "Modo de Ver";
$language['LANG_JSADVERTISEMENT_BLOCK_SELECTOR_TH'] = "Selector";
$language['LANG_JSADVERTISEMENT_CODE'] = "Código Javascript Anúncio";
$language['LANG_BUTTON_CREATE_JSADVERTISEMENT'] = "Criar js bloco de anúncio";
$language['LANG_DELETE_JSADVERTISEMENT'] = "bloco de anúncio Excluir js";
$language['LANG_DELETE_JSADVERTISEMENT_QUEST'] = "Você realmente quer apagar o Javascript bloco de anúncio?";

$language['LANG_JSADVERTISEMENT_CREATE_TITLE'] = "Javascript Anúncio criar novo bloco";
$language['LANG_JSADVERTISEMENT_EDIT_TITLE'] = "Javascript Anúncio editar bloco";
$language['LANG_JSADVERTISEMENT_DELETE_TITLE'] = "Javascript Anúncio excluir bloco";
$language['LANG_JSADVERTISEMENT_SETTINGS_MENU'] = "Anúncio configurações JS";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_1'] = "Javascript bloco Anúncio";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_2'] = "foi criado com sucesso!";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_1'] = "Javascript bloco Anúncio";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_2'] = "foi salva com sucesso!";
$language['LANG_JSADVERTISEMENT_DELETE_SUCCESS'] = "Javascript bloco Anúncio foi excluído com sucesso!";
?>