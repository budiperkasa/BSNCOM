<?php

$language['LANG_CALENDAR_SETTINGS_MENU'] = "Widget definições da Agenda";
$language['LANG_CALENDAR_SETTINGS_TITLE'] = "Widget definições da Agenda";
$language['LANG_CALENDAR_NAME'] = "Calendário nome do widget";
$language['LANG_CALENDAR_ANY_TYPE'] = "Qualquer tipo";
$language['LANG_CALENDAR_TYPE'] = "Conectado tipo";
$language['LANG_CALENDAR_FIELD'] = "Conectado campo de conteúdo";
$language['LANG_CALENDAR_SEARCH_BY_CREATION_DATE'] = "Data de criação";
$language['LANG_CALENDAR_VISIBILITY_INDEX'] = "Widget visível na página do índice";
$language['LANG_VISIBILE'] = "visível";
$language['LANG_NOT_VISIBILE'] = "não visível";
$language['LANG_CALENDAR_VISIBILITY_FOR_TYPES'] = "Widget visível para os tipos";
$language['LANG_CALENDAR_VISIBILITY_FOR_ALL_TYPES'] = "para qualquer tipo";
$language['LANG_CALENDAR_VISIBILITY_FOR_CONNECTED_TYPE'] = "somente para o tipo ligado";
$language['LANG_CALENDAR_SAVE_SUCCESS'] = "Definições do calendário foram salvas com sucesso!";
?>