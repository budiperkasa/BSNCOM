<?php
	
	

$language['LANG_SEND_EMAIL_MESSAGE_TITLE'] = "Enviar e-mail";
$language['LANG_MESSAGE_FROM'] = "Mensagem";
$language['LANG_YOUR_NAME'] = "Seu nome";
$language['LANG_YOUR_EMAIL'] = "Seu e-mail";
$language['LANG_MESSAGE_TO'] = "Mensagem para";
$language['LANG_RECIPIENT_NAME'] = "Nome do destinatário";
$language['LANG_RECIPIENT_EMAIL'] = "e-mail do destinatário";
$language['LANG_SEND_SUCCESS'] = "Enviar mensagem foi enviada com sucesso!";
$language['LANG_SUBJECT'] = "Assunto";
$language['LANG_MESSAGE'] = "Mensagem";
$language['LANG_FILL_CAPTCHA'] = "Preencha o texto de segurança";
$language['LANG_BUTTON_SEND'] = "Enviar";
$language['LANG_BUTTON_CLOSE'] = "Fechar";
$language['LANG_CAPTCHA'] = "campo Captcha";

$language['LANG_EMAIL_FRIEND_SUBJ'] = "Aqui você encontra informações sobre";
$language['LANG_EMAIL_OWNER_SUBJ'] = "De acordo com o seu anúncio";
$language['LANG_EMAIL_REPORT_SUBJ'] = "Relatório sobre o anúncio";
?>