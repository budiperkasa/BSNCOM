<?php

$language['LANG_CONTACTUS_LINK'] = "Contacte-nos";
$language['LANG_CONTACT_US_TITLE'] = "Contacte-nos";
$language['LANG_CONTACTUS_NAME'] = "Seu nome";
$language['LANG_CONTACTUS_EMAIL'] = "Seu e-mail";
$language['LANG_CONTACTUS_SUBJECT'] = "Assunto da mensagem";
$language['LANG_CONTACTUS_BODY'] = "Corpo da mensagem";
$language['LANG_CONTACTUS_SEND_BUTTON'] = "Enviar";

$language['LANG_CONTACTUS_SUCCESS'] = "Mensagem foi enviada com sucesso!";
$language['LANG_ENABLE_CONTACTUS_PAGE'] = "Habilitar contato nós página";
?>