<?php

$language['LANG_FACEBOOK_LOGIN_BTN'] = "Facebook Login";
$language['LANG_FACEBOOK_SETTINGS'] = "Facebook Configurações";
$language['LANG_FACEBOOK_API_KEY'] = "Facebook chave de API";
$language['LANG_FACEBOOK_APP_ID'] = "Facebook Application ID";
$language['LANG_FACEBOOK_API_KEY_SIGNUP'] = "<a href='http://www.facebook.com/developers/createapp.php' target='_blank'>Registre</a> seu Facebook Application";
$language['LANG_FACEBOOK_APP_SECRET'] = "Facebook Application palavra secreta";
?>