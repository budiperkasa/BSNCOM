<?php
	
	

$language['LANG_SEND_EMAIL_MESSAGE_TITLE'] = "Отправить сообщение электронной почты";
$language['LANG_MESSAGE_FROM'] = "Сообщение от";
$language['LANG_YOUR_NAME'] = "Ваше имя";
$language['LANG_YOUR_EMAIL'] = "Ваш адрес электронной почты";
$language['LANG_MESSAGE_TO'] = "Сообщение для";
$language['LANG_RECIPIENT_NAME'] = "Имя получателя";
$language['LANG_RECIPIENT_EMAIL'] = "Получатель электронной почты";
$language['LANG_SEND_SUCCESS'] = "Отправить сообщение было послано!";
$language['LANG_SUBJECT'] = "Тема";
$language['LANG_MESSAGE'] = "Сообщение";
$language['LANG_FILL_CAPTCHA'] = "Заполните безопасности текст";
$language['LANG_BUTTON_SEND'] = "Отправить";
$language['LANG_BUTTON_CLOSE'] = "Закрыть";
$language['LANG_CAPTCHA'] = "Captcha поле";

$language['LANG_EMAIL_FRIEND_SUBJ'] = "Вот информация о";
$language['LANG_EMAIL_OWNER_SUBJ'] = "По вашей компании";
$language['LANG_EMAIL_REPORT_SUBJ'] = "Доклад о листинге";
?>