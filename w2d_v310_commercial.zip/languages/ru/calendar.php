<?php

$language['LANG_CALENDAR_SETTINGS_MENU'] = "Настройки календаря виджет";
$language['LANG_CALENDAR_SETTINGS_TITLE'] = "Настройки календаря виджет";
$language['LANG_CALENDAR_NAME'] = "Календарь имя виджета";
$language['LANG_CALENDAR_ANY_TYPE'] = "Любой тип";
$language['LANG_CALENDAR_TYPE'] = "Подключенного";
$language['LANG_CALENDAR_FIELD'] = "Связанные содержание поля";
$language['LANG_CALENDAR_SEARCH_BY_CREATION_DATE'] = "Дата создания";
$language['LANG_CALENDAR_VISIBILITY_INDEX'] = "Виджет видны на главную страницу";
$language['LANG_VISIBILE'] = "видимый";
$language['LANG_NOT_VISIBILE'] = "не видно";
$language['LANG_CALENDAR_VISIBILITY_FOR_TYPES'] = "Виджет видимой для типов";
$language['LANG_CALENDAR_VISIBILITY_FOR_ALL_TYPES'] = "для любого типа";
$language['LANG_CALENDAR_VISIBILITY_FOR_CONNECTED_TYPE'] = "только для подключенного";
$language['LANG_CALENDAR_SAVE_SUCCESS'] = "Настройки календаря были успешно сохранены!";
?>