<?php
	
	
/**
 * Authorization page
 */
$language['LANG_AUTHORIZATION_MENU'] = "Авторизация";
$language['LANG_USER_EMAIL'] = "Электронная почта";
$language['LANG_USER_PASSWORD'] = "Пользователь Пароль";
$language['LANG_USER_LOGIN_ERROR'] = "Электронной почты или пароль неверный!";
$language['LANG_USER_BLOCKED'] = "Пользователь с таким электронной почты была заблокирована администратором!";
/**
 * Login page, login block
 */
$language['LANG_LOGIN_HEADER'] = "Войти";
$language['LANG_LOGIN_EMAIL'] = "Электронная почта";
$language['LANG_LOGIN_PASSWORD'] = "Пароль";
$language['LANG_BUTTON_LOGIN'] = "Войти";
$language['LANG_CREATE_ACCOUNT'] = "Создать учетную запись";
$language['LANG_FORGOT_PASS'] = "Забыли пароль?";
$language['LANG_REMEMBER_ME'] = "Запомнить меня";
?>