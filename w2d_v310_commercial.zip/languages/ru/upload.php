<?php
	
/**
 * Images upload block
 */
$language['LANG_MAX_IMAGE_SIZE'] = "Макс размер изображения";
$language['LANG_MAX_FILE_SIZE'] = "максимальный размер файла";
$language['LANG_NEW_FILE_TITLE'] = "Новое название";
$language['LANG_SYMBOLS_MAX'] = "символов макс";
$language['LANG_BUTTON_UPLOAD_FILE'] = "Загрузить файл";
$language['LANG_UPLOAD_FILE'] = "Загрузить новый файл";
$language['LANG_UPLOAD_IMAGE'] = "Загрузить новый образ";
$language['LANG_SUPPORTED_FORMAT'] = "Поддерживаемые форматы";
$language['LANG_BUTTON_UPLOAD_IMAGE'] = "Загрузка изображений";
$language['LANG_CROP_IMAGE'] = "Обрезка изображения";
?>