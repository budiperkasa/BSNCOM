<?php

$language['LANG_2CHECKOUT_REDIRECT_TITLE'] = "Вы будете перенаправлены на 2Checkout";
$language['LANG_2CHECKOUT_REDIRECT_MANUAL'] = "Если вы не автоматически перенаправлены на 2Checkout в течение 5 секунд ...";
$language['LANG_2CHECKOUT_SID'] = "2CheckOut SID";
$language['LANG_2CHECKOUT_SWORD'] = "2CheckOut секретное слово";
$language['LANG_2CHECKOUT_SWORD_DESCR'] = "Войти в вашу 2checkout.com счета и перейдите в раздел &quot;Внешний вид&quot; разделе. В нижней ввести секретное слово и использовать его в процессе проверки IPN.";
$language['LANG_2CHECKOUT_SETTINGS'] = "2CheckOut настройки";
?>