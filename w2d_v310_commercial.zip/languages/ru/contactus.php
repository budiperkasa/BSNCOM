<?php

$language['LANG_CONTACTUS_LINK'] = "Связаться с нами";
$language['LANG_CONTACT_US_TITLE'] = "Связаться с нами";
$language['LANG_CONTACTUS_NAME'] = "Ваше имя";
$language['LANG_CONTACTUS_EMAIL'] = "Ваш адрес электронной почты";
$language['LANG_CONTACTUS_SUBJECT'] = "Тема сообщения";
$language['LANG_CONTACTUS_BODY'] = "Текст сообщения";
$language['LANG_CONTACTUS_SEND_BUTTON'] = "Отправить";

$language['LANG_CONTACTUS_SUCCESS'] = "Сообщение было послано!";
$language['LANG_ENABLE_CONTACTUS_PAGE'] = "Включить страницу с контактной информацией";
?>