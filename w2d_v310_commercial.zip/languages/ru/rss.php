<?php

$language['LANG_RSS_FEED_RECENT_LISTINGS'] = "Feed последние списки";
$language['LANG_RSS_FEED_TYPE_LISTINGS'] = "Feed списки этого типа";
$language['LANG_RSS_FEED_CATEGORIES_LISTINGS'] = "Feed листингах на этой категории";
$language['LANG_RSS_FEED_SEARCH_LISTINGS'] = "Feed листингах на этой результатах поиска";
$language['LANG_RSS_FEED_IN_LOCATION'] = "в месте";
?>