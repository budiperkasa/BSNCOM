<?php

$language['LANG_JSADVERTISEMENT_MANAGE_BLOCKS_TITLE'] = "Управление Javascript рекламных блоков";
$language['LANG_JSADVERTISEMENT_ALL_BLOCKS'] = "Управление Javascript рекламных блоков";
$language['LANG_CREATE_JSADVERTISEMENT_BLOCK'] = "создать новое объявление JS блок";
$language['LANG_EDIT_JSADVERTISEMENT_BLOCK'] = "Изменить JS рекламного блока";
$language['LANG_CREATE_JSADVERTISEMENT'] = "Создать новый блок рекламы";
$language['LANG_EDIT_JSADVERTISEMENT'] = "Изменить JS рекламного блока";
$language['LANG_DELETE_JSADVERTISEMENT_BLOCK'] = "удалить JS рекламного блока";
$language['LANG_JSADVERTISEMENT_BLOCK_NAME_TH'] = "Имя блока";
$language['LANG_JSADVERTISEMENT_BLOCK_MODE_TH'] = "Режим просмотра";
$language['LANG_JSADVERTISEMENT_BLOCK_SELECTOR_TH'] = "Селектор";
$language['LANG_JSADVERTISEMENT_CODE'] = "Javascript код объявления";
$language['LANG_BUTTON_CREATE_JSADVERTISEMENT'] = "Создать JS рекламного блока";
$language['LANG_DELETE_JSADVERTISEMENT'] = "Удалить объявление JS блок";
$language['LANG_DELETE_JSADVERTISEMENT_QUEST'] = "Вы действительно хотите удалить Javascript рекламного блока?";

$language['LANG_JSADVERTISEMENT_CREATE_TITLE'] = "Javascript Реклама создать новый блок";
$language['LANG_JSADVERTISEMENT_EDIT_TITLE'] = "Javascript Реклама редактирования блок";
$language['LANG_JSADVERTISEMENT_DELETE_TITLE'] = "Javascript Реклама удалить блок";
$language['LANG_JSADVERTISEMENT_SETTINGS_MENU'] = "JS Реклама настройки";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_1'] = "Javascript рекламного блока";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_2'] = "был успешно создан!";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_1'] = "Javascript рекламного блока";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_2'] = "был успешно сохранены!";
$language['LANG_JSADVERTISEMENT_DELETE_SUCCESS'] = "Javascript рекламного блока был успешно удален!";
?>