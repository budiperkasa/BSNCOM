<?php

$language['LANG_ALERTPAY_SETTINGS'] = "AlertPay Настройки";
$language['LANG_ALERTPAY_REDIRECT_TITLE'] = "Вы будете перенаправлены на AlertPay";
$language['LANG_ALERTPAY_REDIRECT_MANUAL'] = "Если вы автоматически не перенаправлены на AlertPay в течение 5 секунд ...";
$language['LANG_ALERTPAY_EMAIL'] = "AlertPay бизнес Email";
$language['LANG_ALERTPAY_SECURITYCODE'] = "AlertPay защитный код.";
$language['LANG_ALERTPAY_SECURITYCODE_DESCR'] = "Должен быть использован для подтверждения того, что IPN был получен от AlertPay, сравнивается с защитным кодом IPN в аккаунте AlertPay.";
?>