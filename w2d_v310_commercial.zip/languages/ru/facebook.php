<?php

$language['LANG_FACEBOOK_LOGIN_BTN'] = "Facebook Войти";
$language['LANG_FACEBOOK_SETTINGS'] = "Того, Настройки";
$language['LANG_FACEBOOK_API_KEY'] = "Facebook API Key";
$language['LANG_FACEBOOK_APP_ID'] = "Facebook Application ID";
$language['LANG_FACEBOOK_API_KEY_SIGNUP'] = "<a href='http://www.facebook.com/developers/createapp.php' target='_blank'>Регистрация</a> Вашего того, применение";
$language['LANG_FACEBOOK_APP_SECRET'] = "Facebook Применение Секретное слово";
?>