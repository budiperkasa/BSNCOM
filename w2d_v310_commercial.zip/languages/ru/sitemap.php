<?php

$language['LANG_SITEMAP_LINK'] = "Карта сайта";
$language['LANG_SITEMAP_TITLE'] = "Карта сайта";
?>