<?php
	

$language['LANG_PAYPAL_SETTINGS'] = "PayPal настройки";
$language['LANG_PAYPAL_REDIRECT_TITLE'] = "Вы будете перенаправлены на PayPal";
$language['LANG_PAYPAL_REDIRECT_MANUAL'] = "Если вы не автоматически перенаправлены на PayPal в течение 5 секунд ...";
$language['LANG_PAYPAL_EMAIL'] = "PayPal бизнес-почта";
?>