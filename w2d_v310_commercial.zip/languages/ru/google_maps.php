<?php

$language['LANG_MAP'] = "Google Map";
$language['LANG_MAPS_SIGNUP'] = "<a href='http://code.google.com/apis/maps/signup.html' target='_blank'>Зарегистрируйтесь</a> на Google Maps API Key";
$language['LANG_MAPS_KEY'] = "Google Maps API ключ";

$language['LANG_BUTTON_MAP'] = "Создать на карте Google";
$language['LANG_ENTER_LTLG_MANUALLY'] = "Ввести вручную широта / долгота";
$language['LANG_HIDE_LTLG_MANUALLY'] = "Геокода широта / долгота с адреса";
$language['LANG_MAP_LATITUDE'] = "Google Map широты";
$language['LANG_MAP_LONGITUDE'] = "Google Map долготы";
$language['LANG_MAP_POINT_ADDRESS'] = "Google карте Адрес точки";
$language['LANG_MAP_ZOOM_LEVEL'] = "Google карта масштаба";

$language['LANG_SELECT_ICON_LISTING'] = "Выберите значок и сохранить листинг";
$language['LANG_SELECT_ICON_LISTING_NOTE'] = "ПРИМЕЧАНИЕ: Иконки набор зависит от выбранных категорий";
$language['LANG_RESET_ICON'] = "Сброс иконки";
$language['LANG_BUTTON_MARKER_ICON'] = "Выберите значок маркера";
$language['LANG_MAP_ICON_ID'] = "Карта маркером значок ID";
$language['LANG_MAP_ICON_FILE'] = "Карта маркером значок файла";
?>