<?php

$language['LANG_EMAIL_NOTIFICATIONS'] = "Изменить уведомление по электронной почте";
$language['LANG_NOTIFICATION_RAISE'] = "Уведомление повышается на";
$language['LANG_NOTIFICATION_SUBJECT'] = "Уведомление теме";
$language['LANG_NOTIFICATION_BODY'] = "Уведомление тела";
$language['LANG_VIEW_EMAIL_NOTIFICATIONS'] = "Просмотр уведомлений электронной почты";
$language['LANG_EDIT_NOTIFICATION_OPTION'] = "редактировать уведомления";
// Controller constants
$language['LANG_VIEW_EMAIL_NOTIFICATIONS_TITLE'] = "Просмотр уведомлений электронной почты";
$language['LANG_EDIT_EMAIL_NOTIFICATIONS_TITLE'] = "Изменить уведомления по электронной почте";
$language['LANG_EMAIL_NOTIFICATIONS_MENU'] = "Уведомления по электронной почте";
$language['LANG_NOTIFICATION_SEND_SUCCESS_1'] = "Уведомление о событии";
$language['LANG_NOTIFICATION_SEND_SUCCESS_2'] = "был успешно сохранены!";
?>