<?php
	
$language['LANG_ALERTPAY_SETTINGS'] = "AlertPay paramètres";
$language['LANG_ALERTPAY_REDIRECT_TITLE'] = "Vous allez être redirigé vers AlertPay";
$language['LANG_ALERTPAY_REDIRECT_MANUAL'] = "Si vous n'êtes pas redirigé automatiquement vers AlertPay dans les 5 secondes ...";
$language['LANG_ALERTPAY_EMAIL'] = "Email affaires AlertPay";
$language['LANG_ALERTPAY_SECURITYCODE'] = "Code de sécurité AlertPay.";
$language['LANG_ALERTPAY_SECURITYCODE_DESCR'] = "devrait être utilisée pour confirmer que l'IPN reçues provenaient de AlertPay Comparez cela à l'IPN dans le code de sécurité de votre compte AlertPay.";
?>