<?php

$language['LANG_FACEBOOK_LOGIN_BTN'] = "Facebook Login";
$language['LANG_FACEBOOK_SETTINGS'] = "Facebook Paramètres";
$language['LANG_FACEBOOK_API_KEY'] = "Facebook clé API";
$language['LANG_FACEBOOK_APP_ID'] = "Application Facebook ID";
$language['LANG_FACEBOOK_API_KEY_SIGNUP'] = "<a href='http://www.facebook.com/developers/createapp.php' target='_blank'>Inscrivez</a> votre application Facebook";
$language['LANG_FACEBOOK_APP_SECRET'] = "Application Facebook Secret mot";
?>