<?php

$language['LANG_INSTALL_STEP1_TITLE'] = "Créer un utilisateur du système racinaire";
$language['LANG_INSTALL_STEP1_SUBTITLE'] = "l'utilisateur root a les privilèges d'accès mondial. Peut ajouter / modifier / supprimer des groupes d'utilisateurs et groupes d'utilisateurs les autorisations.";
$language['LANG_INSTALL_TITLE'] = "L'installation du système";
$language['LANG_INSTALL_USER_LOGIN'] = "connexion de l'utilisateur Root";
$language['LANG_INSTALL_USER_EMAIL'] = "mail de l'utilisateur Root";
$language['LANG_INSTALL_USER_PASSWORD'] = "Mot de passe";
$language['LANG_INSTALL_USER_PASSWORD_REPEAT'] = "répéter Mot de passe";
$language['LANG_INSTALL_BUTTON'] = "Continuer l'installation";
$language['LANG_INSTALL_STEP2_TITLE'] = "paramètres du site Web Set";
$language['LANG_INSTALL_WEBSITE_TITLE'] = "Titre du site";
$language['LANG_INSTALL_WEBSITE_EMAIL'] = "système de messagerie Web";
$language['LANG_INSTALL_FINISH_BUTTON'] = "Installation complète";
$language['LANG_INSTALL_STEP3_TITLE'] = "L'installation a été traitée avec succès!";
$language['LANG_INSTALL_STEP3_SUBTITLE'] = "tables de base de données, l'utilisateur root, les paramètres de site Web a été installé avec succès. Maintenant, allez à la zone admin et installer des modules additionnels, de remplir d'autres paramètres système. Avant que vous pouvez créer votre première liste, vous devez créer les types et niveaux d'inscriptions, également gérer les catégories et les lieux. Regardez à travers champs et des champs contenu du contenu des groupes.";
?>