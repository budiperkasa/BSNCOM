<?php

$language['LANG_RSS_FEED_RECENT_LISTINGS'] = "RSS des dernières annonces";
$language['LANG_RSS_FEED_TYPE_LISTINGS'] = "Feed annonces de ce type";
$language['LANG_RSS_FEED_CATEGORIES_LISTINGS'] = "Feed annonces de cette catégorie";
$language['LANG_RSS_FEED_SEARCH_LISTINGS'] = "Feed annonces de résultats de recherche";
$language['LANG_RSS_FEED_IN_LOCATION'] = "dans un endroit";
?>