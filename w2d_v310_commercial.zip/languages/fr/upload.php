<?php
	
/**
 * Images upload block
 */
$language['LANG_MAX_IMAGE_SIZE'] = "taille d'image maximale";
$language['LANG_MAX_FILE_SIZE'] = "taille de fichier max";
$language['LANG_NEW_FILE_TITLE'] = "le titre du dossier Nouveau";
$language['LANG_SYMBOLS_MAX'] = "max symboles";
$language['LANG_BUTTON_UPLOAD_FILE'] = "Importer un fichier";
$language['LANG_UPLOAD_FILE'] = "Envoyer un nouveau fichier";
$language['LANG_UPLOAD_IMAGE'] = "Envoyer une nouvelle image";
$language['LANG_SUPPORTED_FORMAT'] = "Les formats supportés";
$language['LANG_BUTTON_UPLOAD_IMAGE'] = "Importer un fichier";
$language['LANG_CROP_IMAGE'] = "Recadrer l'image";
?>