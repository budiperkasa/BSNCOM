<?php

$language['LANG_CONTACTUS_LINK'] = "Contactez-nous";
$language['LANG_CONTACT_US_TITLE'] = "Contactez-nous";
$language['LANG_CONTACTUS_NAME'] = "Votre nom";
$language['LANG_CONTACTUS_EMAIL'] = "Votre e-mail";
$language['LANG_CONTACTUS_SUBJECT'] = "Objet du message";
$language['LANG_CONTACTUS_BODY'] = "Corps du message";
$language['LANG_CONTACTUS_SEND_BUTTON'] = "Envoyer";

$language['LANG_CONTACTUS_SUCCESS'] = "Message a été envoyé avec succès!";
$language['LANG_ENABLE_CONTACTUS_PAGE'] = "Activer page contactez-nous";
?>