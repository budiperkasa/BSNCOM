<?php

$language['LANG_CALENDAR_SETTINGS_MENU'] = "paramètres widget Calendrier";
$language['LANG_CALENDAR_SETTINGS_TITLE'] = "paramètres widget Calendrier";
$language['LANG_CALENDAR_NAME'] = "nom du widget Calendrier";
$language['LANG_CALENDAR_ANY_TYPE'] = "N'importe quel type";
$language['LANG_CALENDAR_TYPE'] = "Connecté type";
$language['LANG_CALENDAR_FIELD'] = "Connecté sur le terrain du contenu";
$language['LANG_CALENDAR_SEARCH_BY_CREATION_DATE'] = "Date de création";
$language['LANG_CALENDAR_VISIBILITY_INDEX'] = "Widget visible sur la page d'index";
$language['LANG_VISIBILE'] = "visible";
$language['LANG_NOT_VISIBILE'] = "pas visible";
$language['LANG_CALENDAR_VISIBILITY_FOR_TYPES'] = "visible pour les types de Widget";
$language['LANG_CALENDAR_VISIBILITY_FOR_ALL_TYPES'] = "pour tout type";
$language['LANG_CALENDAR_VISIBILITY_FOR_CONNECTED_TYPE'] = "uniquement pour le type connecté";
$language['LANG_CALENDAR_SAVE_SUCCESS'] = "Paramètres de l'agenda ont été enregistrées avec succès!";
?>