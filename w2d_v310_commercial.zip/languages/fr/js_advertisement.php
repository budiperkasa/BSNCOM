<?php

$language['LANG_JSADVERTISEMENT_MANAGE_BLOCKS_TITLE'] = "Gérer Javascript blocs Publicité";
$language['LANG_JSADVERTISEMENT_ALL_BLOCKS'] = "Gérer Javascript blocs Publicité";
$language['LANG_CREATE_JSADVERTISEMENT_BLOCK'] = "créer de nouveaux blocs de publicité js";
$language['LANG_EDIT_JSADVERTISEMENT_BLOCK'] = "modifier le bloc publicitaire js";
$language['LANG_CREATE_JSADVERTISEMENT'] = "Créer bloc nouvelle annonce";
$language['LANG_EDIT_JSADVERTISEMENT'] = "Modifier le bloc publicitaire js";
$language['LANG_DELETE_JSADVERTISEMENT_BLOCK'] = "supprimer le bloc de publicité js";
$language['LANG_JSADVERTISEMENT_BLOCK_NAME_TH'] = "Nom du bloc";
$language['LANG_JSADVERTISEMENT_BLOCK_MODE_TH'] = "Voir le mode";
$language['LANG_JSADVERTISEMENT_BLOCK_SELECTOR_TH'] = "Sélecteur";
$language['LANG_JSADVERTISEMENT_CODE'] = "Javascript Publicité code";
$language['LANG_BUTTON_CREATE_JSADVERTISEMENT'] = "js Créer bloc publicité";
$language['LANG_DELETE_JSADVERTISEMENT'] = "Supprimer la publicité bloc js";
$language['LANG_DELETE_JSADVERTISEMENT_QUEST'] = "Voulez-vous vraiment supprimer Javascript Publicité bloc?";

$language['LANG_JSADVERTISEMENT_CREATE_TITLE'] = "Javascript Publicité créer nouveau bloc";
$language['LANG_JSADVERTISEMENT_EDIT_TITLE'] = "Javascript Publicité modifier bloc";
$language['LANG_JSADVERTISEMENT_DELETE_TITLE'] = "Javascript Publicité supprimer bloc";
$language['LANG_JSADVERTISEMENT_SETTINGS_MENU'] = "JS paramètres Publicité";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_1'] = "Javascript Publicité bloc";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_2'] = "a été créé avec succès!";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_1'] = "Javascript Publicité bloc";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_2'] = "a été enregistré avec succès!";
$language['LANG_JSADVERTISEMENT_DELETE_SUCCESS'] = "Javascript Publicité bloc a été supprimé avec succès!";
?>