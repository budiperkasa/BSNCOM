<?php
	
	

$language['LANG_SEND_EMAIL_MESSAGE_TITLE'] = "Envoyer un message e-mail";
$language['LANG_MESSAGE_FROM'] = "Message de";
$language['LANG_YOUR_NAME'] = "Votre nom";
$language['LANG_YOUR_EMAIL'] = "Votre e-mail";
$language['LANG_MESSAGE_TO'] = "Message à";
$language['LANG_RECIPIENT_NAME'] = "Nom du récipiendaire";
$language['LANG_RECIPIENT_EMAIL'] = "Courriel du destinataire";
$language['LANG_SEND_SUCCESS'] = "Email message a été envoyé avec succès!";
$language['LANG_SUBJECT'] = "Sous réserve";
$language['LANG_MESSAGE'] = "Message";
$language['LANG_FILL_CAPTCHA'] = "Remplissez la sécurité texte";
$language['LANG_BUTTON_SEND'] = "Envoyer";
$language['LANG_BUTTON_CLOSE'] = "Fermer";
$language['LANG_CAPTCHA'] = "domaine Captcha";

$language['LANG_EMAIL_FRIEND_SUBJ'] = "Voici des informations sur";
$language['LANG_EMAIL_OWNER_SUBJ'] = "Selon votre annonce";
$language['LANG_EMAIL_REPORT_SUBJ'] = "Rapport sur l'inscription";
?>