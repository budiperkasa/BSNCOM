<?php
	
	
/**
 * Authorization page
 */
$language['LANG_AUTHORIZATION_MENU'] = "Autorisation";
$language['LANG_USER_EMAIL'] = "Email";
$language['LANG_USER_PASSWORD'] = "Mot de passe";
$language['LANG_USER_LOGIN_ERROR'] = "Email ou mot de passe est incorrect!";
$language['LANG_USER_BLOCKED'] = "L'utilisateur par email a été bloqué par ces admin!";
/**
 * Login page, login block
 */
$language['LANG_LOGIN_HEADER'] = "Connectez-vous";
$language['LANG_LOGIN_EMAIL'] = "Email";
$language['LANG_LOGIN_PASSWORD'] = "Mot de passe";
$language['LANG_BUTTON_LOGIN'] = "Connectez-vous";
$language['LANG_CREATE_ACCOUNT'] = "Créer un compte";
$language['LANG_FORGOT_PASS'] = "Mot de passe oublié?";
$language['LANG_REMEMBER_ME'] = "Se souvenir de moi";
?>