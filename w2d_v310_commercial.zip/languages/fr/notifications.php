<?php

$language['LANG_EMAIL_NOTIFICATIONS'] = "Modifier la notification par email";
$language['LANG_NOTIFICATION_RAISE'] = "Notification soulève le";
$language['LANG_NOTIFICATION_SUBJECT'] = "sous réserve de notification";
$language['LANG_NOTIFICATION_BODY'] = "Notification du corps";
$language['LANG_VIEW_EMAIL_NOTIFICATIONS'] = "des notifications par email Voir";
$language['LANG_EDIT_NOTIFICATION_OPTION'] = "modifier la notification";
// Controller constants
$language['LANG_VIEW_EMAIL_NOTIFICATIONS_TITLE'] = "des notifications par email Voir";
$language['LANG_EDIT_EMAIL_NOTIFICATIONS_TITLE'] = "Modifier les notifications par email";
$language['LANG_EMAIL_NOTIFICATIONS_MENU'] = "Les notifications par courriel";
$language['LANG_NOTIFICATION_SEND_SUCCESS_1'] = "Notification sur l'évènement";
$language['LANG_NOTIFICATION_SEND_SUCCESS_2'] = "a été enregistré avec succès!";
?>