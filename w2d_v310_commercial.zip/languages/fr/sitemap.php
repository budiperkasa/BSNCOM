<?php

$language['LANG_SITEMAP_LINK'] = "Plan du site";
$language['LANG_SITEMAP_TITLE'] = "Plan du site";
?>