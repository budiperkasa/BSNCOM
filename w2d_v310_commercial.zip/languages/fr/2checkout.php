<?php

$language['LANG_2CHECKOUT_REDIRECT_TITLE'] = "Vous allez être redirigé vers 2Checkout";
$language['LANG_2CHECKOUT_REDIRECT_MANUAL'] = "Si vous n'êtes pas automatiquement redirigé vers 2Checkout dans les 5 secondes ...";
$language['LANG_2CHECKOUT_SID'] = "2CheckOut sid";
$language['LANG_2CHECKOUT_SWORD'] = "2CheckOut mot secret";
$language['LANG_2CHECKOUT_SWORD_DESCR'] = "Connectez-vous à votre compte 2checkout.com et aller sur «Look and Feel' section. Au bas entrer le mot secret et l'utiliser dans le processus de vérification IPN.";
$language['LANG_2CHECKOUT_SETTINGS'] = "paramètres 2CheckOut";
?>