<?php

$language['LANG_MAP'] = "Google Map";
$language['LANG_MAPS_SIGNUP'] = "<a href='http://code.google.com/apis/maps/signup.html' target='_blank'>Inscrivez-vous sur</a> une clé API Google Maps";
$language['LANG_MAPS_KEY'] = "Google Maps API clés";

$language['LANG_BUTTON_MAP'] = "Générer sur google map";
$language['LANG_ENTER_LTLG_MANUALLY'] = "Entrer manuellement Latitude / Longitude";
$language['LANG_HIDE_LTLG_MANUALLY'] = "Géocode Latitude / Longitude de l'adresse";
$language['LANG_MAP_LATITUDE'] = "latitude carte Google";
$language['LANG_MAP_LONGITUDE'] = "longitude carte Google";
$language['LANG_MAP_POINT_ADDRESS'] = "l'adresse de Google point de la carte";
$language['LANG_MAP_ZOOM_LEVEL'] = "Google map niveau de zoom";

$language['LANG_SELECT_ICON_LISTING'] = "Sélectionnez l'icône et enregistrer annonce";
$language['LANG_SELECT_ICON_LISTING_NOTE'] = "NOTE: définir des icônes dépend de certaines catégories";
$language['LANG_RESET_ICON'] = "icône Reset";
$language['LANG_BUTTON_MARKER_ICON'] = "Sélectionnez l'icône marqueur";
$language['LANG_MAP_ICON_ID'] = "Carte icône marqueur d'identification,";
$language['LANG_MAP_ICON_FILE'] = "Carte icône du fichier de marqueur";
?>