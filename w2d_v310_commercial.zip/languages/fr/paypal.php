<?php
	

$language['LANG_PAYPAL_SETTINGS'] = "paramètres de PayPal";
$language['LANG_PAYPAL_REDIRECT_TITLE'] = "Vous allez être redirigé vers PayPal";
$language['LANG_PAYPAL_REDIRECT_MANUAL'] = "Si vous n'êtes pas automatiquement redirigé vers PayPal dans les 5 secondes ...";
$language['LANG_PAYPAL_EMAIL'] = "Email PayPal Business";
?>