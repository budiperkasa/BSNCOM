<?php

$language['LANG_INSTALL_STEP1_TITLE'] = "Erstellen System Root-Benutzer";
$language['LANG_INSTALL_STEP1_SUBTITLE'] = "Root-Benutzer hat die globale Zugriffsrechte. Mai Hinzufügen / Bearbeiten / Löschen von Benutzer-und Benutzergruppen Berechtigungen.";
$language['LANG_INSTALL_TITLE'] = "System-Installation";
$language['LANG_INSTALL_USER_LOGIN'] = "Root Benutzer Login";
$language['LANG_INSTALL_USER_EMAIL'] = "Root-Benutzer E-Mail";
$language['LANG_INSTALL_USER_PASSWORD'] = "Passwort";
$language['LANG_INSTALL_USER_PASSWORD_REPEAT'] = "Passwort wiederholen";
$language['LANG_INSTALL_BUTTON'] = "Installation fortsetzen";
$language['LANG_INSTALL_STEP2_TITLE'] = "Setzen Website-Einstellungen";
$language['LANG_INSTALL_WEBSITE_TITLE'] = "Website Titel";
$language['LANG_INSTALL_WEBSITE_EMAIL'] = "Website-System E-Mail";
$language['LANG_INSTALL_FINISH_BUTTON'] = "Komplette Installation";
$language['LANG_INSTALL_STEP3_TITLE'] = "Die Installation wurde erfolgreich verarbeitet!";
$language['LANG_INSTALL_STEP3_SUBTITLE'] = "Datenbanktabellen, Root-Benutzer war Website-Einstellungen erfolgreich installiert. Nun zu Admin-Bereich gehen und Installation zusätzlicher Module, füllen andere System-Einstellungen. Bevor Sie Ihren ersten Eintrag erstellen können, müssen Sie Arten und Stufen der Inserate erstellen, verwalten auch Kategorien und Orten. Schauen Sie durch Felder und Inhalt Inhalt Felder Gruppen.";
?>