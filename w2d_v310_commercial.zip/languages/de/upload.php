<?php
	
/**
 * Images upload block
 */
$language['LANG_MAX_IMAGE_SIZE'] = "Max Bildgröße";
$language['LANG_MAX_FILE_SIZE'] = "maximale Dateigröße";
$language['LANG_NEW_FILE_TITLE'] = "Neue Datei Titel";
$language['LANG_SYMBOLS_MAX'] = "Symbole max";
$language['LANG_BUTTON_UPLOAD_FILE'] = "Datei hochladen";
$language['LANG_UPLOAD_FILE'] = "Laden Sie neue Datei";
$language['LANG_UPLOAD_IMAGE'] = "Laden Sie neue Bild";
$language['LANG_SUPPORTED_FORMAT'] = "Unterstützte Formate";
$language['LANG_BUTTON_UPLOAD_IMAGE'] = "Bild hochladen";
$language['LANG_CROP_IMAGE'] = "Bild zuschneiden";
?>