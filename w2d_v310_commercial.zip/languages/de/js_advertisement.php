<?php

$language['LANG_JSADVERTISEMENT_MANAGE_BLOCKS_TITLE'] = "Verwalten Sie Javascript Werbung Blöcke";
$language['LANG_JSADVERTISEMENT_ALL_BLOCKS'] = "Verwalten Sie Javascript Werbung Blöcke";
$language['LANG_CREATE_JSADVERTISEMENT_BLOCK'] = "neue js Werbeblock";
$language['LANG_EDIT_JSADVERTISEMENT_BLOCK'] = "bearbeiten js Werbeblock";
$language['LANG_CREATE_JSADVERTISEMENT'] = "Neues Werbeblock";
$language['LANG_EDIT_JSADVERTISEMENT'] = "Bearbeiten js Werbeblock";
$language['LANG_DELETE_JSADVERTISEMENT_BLOCK'] = "js löschen Werbeblock";
$language['LANG_JSADVERTISEMENT_BLOCK_NAME_TH'] = "Blockname";
$language['LANG_JSADVERTISEMENT_BLOCK_MODE_TH'] = "View-Modus";
$language['LANG_JSADVERTISEMENT_BLOCK_SELECTOR_TH'] = "Wähler";
$language['LANG_JSADVERTISEMENT_CODE'] = "Javascript-Code Werbung";
$language['LANG_BUTTON_CREATE_JSADVERTISEMENT'] = "Erstellen js Werbeblock";
$language['LANG_DELETE_JSADVERTISEMENT'] = "Löschen js Werbeblock";
$language['LANG_DELETE_JSADVERTISEMENT_QUEST'] = "Wollen Sie wirklich auf Javascript Werbung Block löschen?";

$language['LANG_JSADVERTISEMENT_CREATE_TITLE'] = "Javascript Werbung neue Block";
$language['LANG_JSADVERTISEMENT_EDIT_TITLE'] = "Javascript Werbung bearbeiten Block";
$language['LANG_JSADVERTISEMENT_DELETE_TITLE'] = "Javascript Werbung löschen Block";
$language['LANG_JSADVERTISEMENT_SETTINGS_MENU'] = "JS Werbung Einstellungen";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_1'] = "Javascript Werbung blockieren";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_2'] = "wurde erfolgreich eingerichtet!";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_1'] = "Javascript Werbung blockieren";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_2'] = "wurde erfolgreich gespeichert!";
$language['LANG_JSADVERTISEMENT_DELETE_SUCCESS'] = "Javascript Werbung Block wurde erfolgreich gelöscht!";
?>