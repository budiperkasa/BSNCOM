<?php

$language['LANG_2CHECKOUT_REDIRECT_TITLE'] = "Sie werden umgeleitet werden 2Checkout";
$language['LANG_2CHECKOUT_REDIRECT_MANUAL'] = "Wenn Sie nicht automatisch zu 2Checkout innerhalb von 5 Sekunden weitergeleitet ...";
$language['LANG_2CHECKOUT_SID'] = "2CheckOut sid";
$language['LANG_2CHECKOUT_SWORD'] = "2CheckOut geheime Wort";
$language['LANG_2CHECKOUT_SWORD_DESCR'] = "Login in Ihre 2checkout.com Konto an und gehen zu &quot;Look and Feel&quot; aus. An der Unterseite geben dem geheimen Wort und verwenden Sie es in der IPN Überprüfung.";
$language['LANG_2CHECKOUT_SETTINGS'] = "2CheckOut Einstellungen";
?>