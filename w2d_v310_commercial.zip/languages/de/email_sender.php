<?php
	
	

$language['LANG_SEND_EMAIL_MESSAGE_TITLE'] = "Senden Sie E-Mail";
$language['LANG_MESSAGE_FROM'] = "Nachricht von";
$language['LANG_YOUR_NAME'] = "Ihr Name";
$language['LANG_YOUR_EMAIL'] = "Ihre E-Mail";
$language['LANG_MESSAGE_TO'] = "Nachricht an";
$language['LANG_RECIPIENT_NAME'] = "Empfänger Name";
$language['LANG_RECIPIENT_EMAIL'] = "Empfänger E-Mail";
$language['LANG_SEND_SUCCESS'] = "E-Mail Nachricht wurde erfolgreich versendet!";
$language['LANG_SUBJECT'] = "Betrifft";
$language['LANG_MESSAGE'] = "Nachricht";
$language['LANG_FILL_CAPTCHA'] = "Füllen Sicherheit Text";
$language['LANG_BUTTON_SEND'] = "Senden";
$language['LANG_BUTTON_CLOSE'] = "Schließen";
$language['LANG_CAPTCHA'] = "Captcha-Feld";

$language['LANG_EMAIL_FRIEND_SUBJ'] = "Hier finden Sie Informationen über";
$language['LANG_EMAIL_OWNER_SUBJ'] = "Nach Ihrem Inserat";
$language['LANG_EMAIL_REPORT_SUBJ'] = "Bericht über Inserat";
?>