<?php

$language['LANG_SITEMAP_LINK'] = "Sitemap";
$language['LANG_SITEMAP_TITLE'] = "Sitemap";
?>