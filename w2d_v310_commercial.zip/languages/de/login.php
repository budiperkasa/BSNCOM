<?php
	
	
/**
 * Authorization page
 */
$language['LANG_AUTHORIZATION_MENU'] = "Authorisierung";
$language['LANG_USER_EMAIL'] = "E-Mail";
$language['LANG_USER_PASSWORD'] = "User Password";
$language['LANG_USER_LOGIN_ERROR'] = "E-Mail oder Passwort falsch ist!";
$language['LANG_USER_BLOCKED'] = "User mit solchen E-Mail wurde von admin gesperrt!";
/**
 * Login page, login block
 */
$language['LANG_LOGIN_HEADER'] = "Login";
$language['LANG_LOGIN_EMAIL'] = "E-Mail";
$language['LANG_LOGIN_PASSWORD'] = "Passwort";
$language['LANG_BUTTON_LOGIN'] = "Anmelden";
$language['LANG_CREATE_ACCOUNT'] = "Erstellen Sie ein Konto";
$language['LANG_FORGOT_PASS'] = "Passwort vergessen?";
$language['LANG_REMEMBER_ME'] = "Erinnere dich an mich";
?>