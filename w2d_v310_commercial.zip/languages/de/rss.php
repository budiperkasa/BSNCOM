<?php

$language['LANG_RSS_FEED_RECENT_LISTINGS'] = "Feed jüngsten Inserate";
$language['LANG_RSS_FEED_TYPE_LISTINGS'] = "Feed Inserate dieser Art";
$language['LANG_RSS_FEED_CATEGORIES_LISTINGS'] = "Feed Anzeigen in dieser Kategorie";
$language['LANG_RSS_FEED_SEARCH_LISTINGS'] = "Feed Inserate von dieser Resultate";
$language['LANG_RSS_FEED_IN_LOCATION'] = "in Lage";
?>