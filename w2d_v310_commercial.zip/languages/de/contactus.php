<?php

$language['LANG_CONTACTUS_LINK'] = "Kontaktieren Sie uns";
$language['LANG_CONTACT_US_TITLE'] = "Kontaktieren Sie uns";
$language['LANG_CONTACTUS_NAME'] = "Ihr Name";
$language['LANG_CONTACTUS_EMAIL'] = "Ihre E-Mail";
$language['LANG_CONTACTUS_SUBJECT'] = "Betreff";
$language['LANG_CONTACTUS_BODY'] = "Nachrichtentext";
$language['LANG_CONTACTUS_SEND_BUTTON'] = "Senden";

$language['LANG_CONTACTUS_SUCCESS'] = "Nachricht wurde erfolgreich gesendet!";
$language['LANG_ENABLE_CONTACTUS_PAGE'] = "Aktivieren Sie Kontakt mit uns auf Seite";
?>