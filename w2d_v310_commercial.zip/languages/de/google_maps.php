<?php

$language['LANG_MAP'] = "Google Map";
$language['LANG_MAPS_SIGNUP'] = "<a href='http://code.google.com/apis/maps/signup.html' target='_blank'>Registriere dich</a> für ein Google Maps API-Schlüssel";
$language['LANG_MAPS_KEY'] = "Google Maps API-Schlüssel";

$language['LANG_BUTTON_MAP'] = "Generieren Sie auf google map";
$language['LANG_ENTER_LTLG_MANUALLY'] = "Geben Sie manuell Breite / Länge";
$language['LANG_HIDE_LTLG_MANUALLY'] = "Geocode Breite / Länge von Adresse";
$language['LANG_MAP_LATITUDE'] = "Google Maps Breite";
$language['LANG_MAP_LONGITUDE'] = "Google map Länge";
$language['LANG_MAP_POINT_ADDRESS'] = "Google Karte zeigen Adresse";
$language['LANG_MAP_ZOOM_LEVEL'] = "Google Karte Zoom-Stufe";

$language['LANG_SELECT_ICON_LISTING'] = "Wählen Sie das Symbol und speichern Inserat";
$language['LANG_SELECT_ICON_LISTING_NOTE'] = "HINWEIS: Icons Set hängt von den ausgewählten Kategorien";
$language['LANG_RESET_ICON'] = "Reset-Symbol";
$language['LANG_BUTTON_MARKER_ICON'] = "Wählen Marker Icon";
$language['LANG_MAP_ICON_ID'] = "Markierung auf der Karte Ikone ID";
$language['LANG_MAP_ICON_FILE'] = "Markierung auf der Karte Icon-Datei";
?>