<?php

$language['LANG_EMAIL_NOTIFICATIONS'] = "Edit E-Mail Benachrichtigung";
$language['LANG_NOTIFICATION_RAISE'] = "Notification wirft auf";
$language['LANG_NOTIFICATION_SUBJECT'] = "Notification Thema";
$language['LANG_NOTIFICATION_BODY'] = "Notification Körper";
$language['LANG_VIEW_EMAIL_NOTIFICATIONS'] = "View-Mail-Benachrichtigungen";
$language['LANG_EDIT_NOTIFICATION_OPTION'] = "Anmeldung bearbeiten";
// Controller constants
$language['LANG_VIEW_EMAIL_NOTIFICATIONS_TITLE'] = "View-Mail-Benachrichtigungen";
$language['LANG_EDIT_EMAIL_NOTIFICATIONS_TITLE'] = "Edit-Mail-Benachrichtigungen";
$language['LANG_EMAIL_NOTIFICATIONS_MENU'] = "E-Mail-Benachrichtigungen";
$language['LANG_NOTIFICATION_SEND_SUCCESS_1'] = "Benachrichtigung bei Veranstaltung";
$language['LANG_NOTIFICATION_SEND_SUCCESS_2'] = "wurde erfolgreich gespeichert!";
?>