<?php

$language['LANG_CALENDAR_SETTINGS_MENU'] = "Kalender-Widget-Einstellungen";
$language['LANG_CALENDAR_SETTINGS_TITLE'] = "Kalender-Widget-Einstellungen";
$language['LANG_CALENDAR_NAME'] = "Kalender-Widget Namen";
$language['LANG_CALENDAR_ANY_TYPE'] = "Jede Art";
$language['LANG_CALENDAR_TYPE'] = "Connected Typ";
$language['LANG_CALENDAR_FIELD'] = "Connected Inhalt Feld";
$language['LANG_CALENDAR_SEARCH_BY_CREATION_DATE'] = "Erstellungsdatum";
$language['LANG_CALENDAR_VISIBILITY_INDEX'] = "Widget sichtbar auf Index-Seite";
$language['LANG_VISIBILE'] = "sichtbar";
$language['LANG_NOT_VISIBILE'] = "nicht sichtbar";
$language['LANG_CALENDAR_VISIBILITY_FOR_TYPES'] = "Widget sichtbar für Typen";
$language['LANG_CALENDAR_VISIBILITY_FOR_ALL_TYPES'] = "für jeden Typ";
$language['LANG_CALENDAR_VISIBILITY_FOR_CONNECTED_TYPE'] = "nur für Dich Typ";
$language['LANG_CALENDAR_SAVE_SUCCESS'] = "Kalender-Einstellungen wurden erfolgreich gespeichert!";
?>