<?php
	
$language['LANG_ALERTPAY_SETTINGS'] = "AlertPay Einstellungen";
$language['LANG_ALERTPAY_REDIRECT_TITLE'] = "Sie werden auf AlertPay umgeleitet werden";
$language['LANG_ALERTPAY_REDIRECT_MANUAL'] = "Wenn Sie nicht automatisch weitergeleitet, um innerhalb von 5 Sekunden AlertPay ...";
$language['LANG_ALERTPAY_EMAIL'] = "AlertPay Business Email";
$language['LANG_ALERTPAY_SECURITYCODE'] = "AlertPay Security code.";
$language['LANG_ALERTPAY_SECURITYCODE_DESCR'] = "Sollte benutzt werden, um zu bestätigen, dass die IPN erhielt von AlertPay kam sein Vergleichen Sie es mit dem IPN Security Code in Ihre AlertPay Konto.";
?>