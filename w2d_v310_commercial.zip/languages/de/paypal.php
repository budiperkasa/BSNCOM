<?php
	

$language['LANG_PAYPAL_SETTINGS'] = "PayPal-Einstellungen";
$language['LANG_PAYPAL_REDIRECT_TITLE'] = "Sie werden an PayPal weitergeleitet";
$language['LANG_PAYPAL_REDIRECT_MANUAL'] = "Wenn Sie nicht automatisch zu PayPal innerhalb von 5 Sekunden weitergeleitet ...";
$language['LANG_PAYPAL_EMAIL'] = "PayPal Business E-Mail";
?>