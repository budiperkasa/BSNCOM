<?php
	

$language['LANG_PAYPAL_SETTINGS'] = "Impostazioni PayPal";
$language['LANG_PAYPAL_REDIRECT_TITLE'] = "Verrai reindirizzato su PayPal";
$language['LANG_PAYPAL_REDIRECT_MANUAL'] = "Se non sei automaticamente reindirizzato a PayPal entro 5 secondi ...";
$language['LANG_PAYPAL_EMAIL'] = "Business PayPal e-mail";
?>