<?php

$language['LANG_SITEMAP_LINK'] = "Mappa del sito";
$language['LANG_SITEMAP_TITLE'] = "Mappa del sito";
?>