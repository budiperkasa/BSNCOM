<?php
	
/**
 * Images upload block
 */
$language['LANG_MAX_IMAGE_SIZE'] = "Max dimensione immagine";
$language['LANG_MAX_FILE_SIZE'] = "massima dimensione del file";
$language['LANG_NEW_FILE_TITLE'] = "Nuovo file Titolo";
$language['LANG_SYMBOLS_MAX'] = "simboli max";
$language['LANG_BUTTON_UPLOAD_FILE'] = "Carica un file";
$language['LANG_UPLOAD_FILE'] = "Carica un file nuovo";
$language['LANG_UPLOAD_IMAGE'] = "Carica nuova immagine";
$language['LANG_SUPPORTED_FORMAT'] = "I formati supportati";
$language['LANG_BUTTON_UPLOAD_IMAGE'] = "Carica immagine";
$language['LANG_CROP_IMAGE'] = "Ritaglia immagine";
?>