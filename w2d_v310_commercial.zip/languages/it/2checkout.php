<?php

$language['LANG_2CHECKOUT_REDIRECT_TITLE'] = "Si verrà reindirizzati alla 2Checkout";
$language['LANG_2CHECKOUT_REDIRECT_MANUAL'] = "Se non sei automaticamente reindirizzato a 2Checkout entro 5 secondi ...";
$language['LANG_2CHECKOUT_SID'] = "2Checkout sid";
$language['LANG_2CHECKOUT_SWORD'] = "2Checkout parola segreta";
$language['LANG_2CHECKOUT_SWORD_DESCR'] = "Login nella tua area 2checkout.com e vai su &#39;Look and Feel&#39; sezione. In fondo inserire la parola segreta e utilizzarlo nel processo di verifica IPN.";
$language['LANG_2CHECKOUT_SETTINGS'] = "2Checkout impostazioni";
?>