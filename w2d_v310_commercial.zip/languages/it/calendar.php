<?php

$language['LANG_CALENDAR_SETTINGS_MENU'] = "Calendario widget impostazioni";
$language['LANG_CALENDAR_SETTINGS_TITLE'] = "Calendario widget impostazioni";
$language['LANG_CALENDAR_NAME'] = "Calendario widget nome";
$language['LANG_CALENDAR_ANY_TYPE'] = "Qualsiasi tipo";
$language['LANG_CALENDAR_TYPE'] = "Collegato tipo";
$language['LANG_CALENDAR_FIELD'] = "Collegato campo dei contenuti";
$language['LANG_CALENDAR_SEARCH_BY_CREATION_DATE'] = "Data di creazione";
$language['LANG_CALENDAR_VISIBILITY_INDEX'] = "Widget visibile sulla pagina indice";
$language['LANG_VISIBILE'] = "visibile";
$language['LANG_NOT_VISIBILE'] = "non visibile";
$language['LANG_CALENDAR_VISIBILITY_FOR_TYPES'] = "visibile per i tipi di Widget";
$language['LANG_CALENDAR_VISIBILITY_FOR_ALL_TYPES'] = "per qualsiasi tipo";
$language['LANG_CALENDAR_VISIBILITY_FOR_CONNECTED_TYPE'] = "solo per il tipo di collegamento";
$language['LANG_CALENDAR_SAVE_SUCCESS'] = "Impostazioni calendario sono state salvate correttamente!";
?>