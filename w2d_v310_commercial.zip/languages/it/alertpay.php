<?php

$language['LANG_ALERTPAY_SETTINGS'] = "AlertPay impostazioni";
$language['LANG_ALERTPAY_REDIRECT_TITLE'] = "Sarai reindirizzato a AlertPay";
$language['LANG_ALERTPAY_REDIRECT_MANUAL'] = "Se non sei automaticamente reindirizzato al AlertPay entro 5 secondi ...";
$language['LANG_ALERTPAY_EMAIL'] = "Business Email AlertPay";
$language['LANG_ALERTPAY_SECURITYCODE'] = "Codice di sicurezza AlertPay.";
$language['LANG_ALERTPAY_SECURITYCODE_DESCR'] = "dovrebbe essere usato per confermare che l'IPN ha ricevuto proveniva da AlertPay confrontarlo con il codice di sicurezza IPN sul tuo conto PayPal..";
?>