<?php

$language['LANG_JSADVERTISEMENT_MANAGE_BLOCKS_TITLE'] = "Gestire Javascript blocchi Pubblicità";
$language['LANG_JSADVERTISEMENT_ALL_BLOCKS'] = "Gestire Javascript blocchi Pubblicità";
$language['LANG_CREATE_JSADVERTISEMENT_BLOCK'] = "creare nuove pubblicità js blocco";
$language['LANG_EDIT_JSADVERTISEMENT_BLOCK'] = "Modificare l&#39;inserzione js blocco";
$language['LANG_CREATE_JSADVERTISEMENT'] = "Crea nuovo blocco pubblicità";
$language['LANG_EDIT_JSADVERTISEMENT'] = "Modificare l&#39;inserzione js blocco";
$language['LANG_DELETE_JSADVERTISEMENT_BLOCK'] = "eliminare pubblicità js blocco";
$language['LANG_JSADVERTISEMENT_BLOCK_NAME_TH'] = "Nome del blocco";
$language['LANG_JSADVERTISEMENT_BLOCK_MODE_TH'] = "Modalità di visualizzazione";
$language['LANG_JSADVERTISEMENT_BLOCK_SELECTOR_TH'] = "Selettore";
$language['LANG_JSADVERTISEMENT_CODE'] = "Pubblicità codice Javascript";
$language['LANG_BUTTON_CREATE_JSADVERTISEMENT'] = "js Creare blocco pubblicità";
$language['LANG_DELETE_JSADVERTISEMENT'] = "Elimina js pubblicità blocco";
$language['LANG_DELETE_JSADVERTISEMENT_QUEST'] = "Sei sicuro di voler cancellare Javascript bloccare Pubblicità?";

$language['LANG_JSADVERTISEMENT_CREATE_TITLE'] = "Javascript Pubblicità creare nuovo blocco";
$language['LANG_JSADVERTISEMENT_EDIT_TITLE'] = "Javascript Pubblicità modificare blocco";
$language['LANG_JSADVERTISEMENT_DELETE_TITLE'] = "Javascript Pubblicità cancellazione di un blocco";
$language['LANG_JSADVERTISEMENT_SETTINGS_MENU'] = "JS Pubblicità impostazioni";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_1'] = "Javascript Pubblicità blocco";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_2'] = "è stato creato con successo!";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_1'] = "Javascript Pubblicità blocco";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_2'] = "è stato salvato con successo!";
$language['LANG_JSADVERTISEMENT_DELETE_SUCCESS'] = "Pubblicità Javascript blocco è stato eliminato con successo!";
?>