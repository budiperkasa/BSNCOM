<?php

$language['LANG_FACEBOOK_LOGIN_BTN'] = "Facebook Login";
$language['LANG_FACEBOOK_SETTINGS'] = "Facebook Impostazioni";
$language['LANG_FACEBOOK_API_KEY'] = "Facebook chiave API";
$language['LANG_FACEBOOK_APP_ID'] = "Facebook Application ID";
$language['LANG_FACEBOOK_API_KEY_SIGNUP'] = "<a href='http://www.facebook.com/developers/createapp.php' target='_blank'>Registra</a> la tua applicazione Facebook";
$language['LANG_FACEBOOK_APP_SECRET'] = "Applicazione Facebook parola segreta";
?>