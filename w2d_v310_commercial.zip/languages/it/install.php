<?php

$language['LANG_INSTALL_STEP1_TITLE'] = "Creare l&#39;utente root di sistema";
$language['LANG_INSTALL_STEP1_SUBTITLE'] = "utente root ha i privilegi di accesso globale. Possono aggiungere / modificare / eliminare gruppi di utenti e gruppi di utenti autorizzazioni.";
$language['LANG_INSTALL_TITLE'] = "Sistema di installazione";
$language['LANG_INSTALL_USER_LOGIN'] = "Utente root login";
$language['LANG_INSTALL_USER_EMAIL'] = "L&#39;utente root e-mail";
$language['LANG_INSTALL_USER_PASSWORD'] = "Password";
$language['LANG_INSTALL_USER_PASSWORD_REPEAT'] = "Password ripetere";
$language['LANG_INSTALL_BUTTON'] = "Continuare l&#39;installazione";
$language['LANG_INSTALL_STEP2_TITLE'] = "Impostare le impostazioni di sito web";
$language['LANG_INSTALL_WEBSITE_TITLE'] = "Titolo del sito";
$language['LANG_INSTALL_WEBSITE_EMAIL'] = "Sito web sistema di posta elettronica";
$language['LANG_INSTALL_FINISH_BUTTON'] = "Completare l&#39;installazione";
$language['LANG_INSTALL_STEP3_TITLE'] = "L&#39;installazione è stata elaborata con successo!";
$language['LANG_INSTALL_STEP3_SUBTITLE'] = "tabelle di database, utente root, le impostazioni di sito web è stato installato correttamente. Ora vai a zona admin e installare moduli aggiuntivi, compilare in altre impostazioni di sistema. Prima è possibile creare la tua lista in primo luogo, si deve creare tipi e livelli di inserzioni, anche gestire le categorie e posizioni. Guardare attraverso i campi di contenuti e campi di gruppi di contenuti.";
?>