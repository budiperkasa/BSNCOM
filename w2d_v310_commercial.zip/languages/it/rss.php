<?php

$language['LANG_RSS_FEED_RECENT_LISTINGS'] = "Feed annunci recenti";
$language['LANG_RSS_FEED_TYPE_LISTINGS'] = "Feed annunci di questo tipo";
$language['LANG_RSS_FEED_CATEGORIES_LISTINGS'] = "Feed annunci di questa categoria";
$language['LANG_RSS_FEED_SEARCH_LISTINGS'] = "Feed annunci di questo i risultati della ricerca";
$language['LANG_RSS_FEED_IN_LOCATION'] = "in posizione";
?>