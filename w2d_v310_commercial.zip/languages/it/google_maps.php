<?php

$language['LANG_MAP'] = "Google Map";
$language['LANG_MAPS_SIGNUP'] = "<a href='http://code.google.com/apis/maps/signup.html' target='_blank'>Registrati su</a> di una chiave API di Google Maps";
$language['LANG_MAPS_KEY'] = "Google Maps API chiave";

$language['LANG_BUTTON_MAP'] = "Generare su google map";
$language['LANG_ENTER_LTLG_MANUALLY'] = "Inserire manualmente latitudine / longitudine";
$language['LANG_HIDE_LTLG_MANUALLY'] = "Geocode latitudine / longitudine di indirizzo";
$language['LANG_MAP_LATITUDE'] = "Google map latitudine";
$language['LANG_MAP_LONGITUDE'] = "Google map longitudine";
$language['LANG_MAP_POINT_ADDRESS'] = "Google map indirizzo del punto";
$language['LANG_MAP_ZOOM_LEVEL'] = "Google mappa il livello di zoom";

$language['LANG_SELECT_ICON_LISTING'] = "Selezionare l&#39;icona e salvare annuncio";
$language['LANG_SELECT_ICON_LISTING_NOTE'] = "NOTA: impostare icone dipende categorie selezionate";
$language['LANG_RESET_ICON'] = "Reset icona";
$language['LANG_BUTTON_MARKER_ICON'] = "Seleziona l&#39;icona marcatore";
$language['LANG_MAP_ICON_ID'] = "Mappa marcatore icona ID";
$language['LANG_MAP_ICON_FILE'] = "Mappa marcatore file icon";
?>