<?php
	
	
/**
 * Authorization page
 */
$language['LANG_AUTHORIZATION_MENU'] = "Autorizzazione";
$language['LANG_USER_EMAIL'] = "E-mail";
$language['LANG_USER_PASSWORD'] = "Utente Password";
$language['LANG_USER_LOGIN_ERROR'] = "Email o password non è corretta!";
$language['LANG_USER_BLOCKED'] = "Utente con tale e-mail è stato bloccato da admin!";
/**
 * Login page, login block
 */
$language['LANG_LOGIN_HEADER'] = "Login";
$language['LANG_LOGIN_EMAIL'] = "E-mail";
$language['LANG_LOGIN_PASSWORD'] = "Password";
$language['LANG_BUTTON_LOGIN'] = "Entra";
$language['LANG_CREATE_ACCOUNT'] = "Crea un account";
$language['LANG_FORGOT_PASS'] = "Hai dimenticato la password?";
$language['LANG_REMEMBER_ME'] = "Ricordati di me";
?>