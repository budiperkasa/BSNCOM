<?php

$language['LANG_CONTACTUS_LINK'] = "Contattaci";
$language['LANG_CONTACT_US_TITLE'] = "Contattaci";
$language['LANG_CONTACTUS_NAME'] = "Il tuo nome";
$language['LANG_CONTACTUS_EMAIL'] = "Il tuo indirizzo email";
$language['LANG_CONTACTUS_SUBJECT'] = "Oggetto del messaggio";
$language['LANG_CONTACTUS_BODY'] = "Corpo del messaggio";
$language['LANG_CONTACTUS_SEND_BUTTON'] = "Invia";

$language['LANG_CONTACTUS_SUCCESS'] = "Il messaggio è stato inviata con successo!";
$language['LANG_ENABLE_CONTACTUS_PAGE'] = "Abilita pagina Contattaci";
?>