<?php
	
	

$language['LANG_SEND_EMAIL_MESSAGE_TITLE'] = "Invia un messaggio e-mail";
$language['LANG_MESSAGE_FROM'] = "Messaggio da";
$language['LANG_YOUR_NAME'] = "Il tuo nome";
$language['LANG_YOUR_EMAIL'] = "Il tuo indirizzo email";
$language['LANG_MESSAGE_TO'] = "Messaggio a";
$language['LANG_RECIPIENT_NAME'] = "Il nome del destinatario";
$language['LANG_RECIPIENT_EMAIL'] = "Indirizzo e-mail";
$language['LANG_SEND_SUCCESS'] = "messaggio e-mail è stata inviata con successo!";
$language['LANG_SUBJECT'] = "Oggetto";
$language['LANG_MESSAGE'] = "Messaggio";
$language['LANG_FILL_CAPTCHA'] = "Compila sicurezza testo";
$language['LANG_BUTTON_SEND'] = "Invia";
$language['LANG_BUTTON_CLOSE'] = "Chiudi";
$language['LANG_CAPTCHA'] = "Captcha campo";

$language['LANG_EMAIL_FRIEND_SUBJ'] = "Ecco alcune informazioni su";
$language['LANG_EMAIL_OWNER_SUBJ'] = "Secondo il tuo annuncio";
$language['LANG_EMAIL_REPORT_SUBJ'] = "Segnala su annuncio";
?>