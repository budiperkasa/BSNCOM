<?php

$language['LANG_EMAIL_NOTIFICATIONS'] = "Modifica notifica e-mail";
$language['LANG_NOTIFICATION_RAISE'] = "Notifica solleva su";
$language['LANG_NOTIFICATION_SUBJECT'] = "Notifica soggetto";
$language['LANG_NOTIFICATION_BODY'] = "Notifica corpo";
$language['LANG_VIEW_EMAIL_NOTIFICATIONS'] = "Visualizza le notifiche e-mail";
$language['LANG_EDIT_NOTIFICATION_OPTION'] = "edit notifica";
// Controller constants
$language['LANG_VIEW_EMAIL_NOTIFICATIONS_TITLE'] = "Visualizza le notifiche e-mail";
$language['LANG_EDIT_EMAIL_NOTIFICATIONS_TITLE'] = "Modifica notifiche e-mail";
$language['LANG_EMAIL_NOTIFICATIONS_MENU'] = "Notifiche email";
$language['LANG_NOTIFICATION_SEND_SUCCESS_1'] = "Notifica in caso";
$language['LANG_NOTIFICATION_SEND_SUCCESS_2'] = "è stato salvato con successo!";
?>