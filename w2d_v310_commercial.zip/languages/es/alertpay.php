<?php

$language['LANG_ALERTPAY_SETTINGS'] = "AlertPay ajustes";
$language['LANG_ALERTPAY_REDIRECT_TITLE'] = "Usted será redirigido a AlertPay";
$language['LANG_ALERTPAY_REDIRECT_MANUAL'] = "Si no se redirigen automáticamente a AlertPay en 5 segundos ...";
$language['LANG_ALERTPAY_EMAIL'] = "El correo electrónico de negocios AlertPay";
$language['LANG_ALERTPAY_SECURITYCODE'] = "El código de seguridad AlertPay.";
$language['LANG_ALERTPAY_SECURITYCODE_DESCR'] = "Debe ser utilizado para confirmar que el IPN recibió provino de AlertPay Compárelo con el Código de Seguridad IPN en su cuenta de AlertPay..";
?>