<?php

$language['LANG_JSADVERTISEMENT_MANAGE_BLOCKS_TITLE'] = "Administrar Javascript bloques Publicidad";
$language['LANG_JSADVERTISEMENT_ALL_BLOCKS'] = "Administrar Javascript bloques Publicidad";
$language['LANG_CREATE_JSADVERTISEMENT_BLOCK'] = "crear nuevo bloque anuncio js";
$language['LANG_EDIT_JSADVERTISEMENT_BLOCK'] = "edición bloque js publicidad";
$language['LANG_CREATE_JSADVERTISEMENT'] = "Crear bloque nuevo anuncio";
$language['LANG_EDIT_JSADVERTISEMENT'] = "Editar bloque de publicidad js";
$language['LANG_DELETE_JSADVERTISEMENT_BLOCK'] = "eliminar el bloque js publicidad";
$language['LANG_JSADVERTISEMENT_BLOCK_NAME_TH'] = "Bloque nombre";
$language['LANG_JSADVERTISEMENT_BLOCK_MODE_TH'] = "Ver el modo de";
$language['LANG_JSADVERTISEMENT_BLOCK_SELECTOR_TH'] = "Selector";
$language['LANG_JSADVERTISEMENT_CODE'] = "Publicidad código Javascript";
$language['LANG_BUTTON_CREATE_JSADVERTISEMENT'] = "Crear js bloque de publicidad";
$language['LANG_DELETE_JSADVERTISEMENT'] = "Eliminar js bloque de publicidad";
$language['LANG_DELETE_JSADVERTISEMENT_QUEST'] = "¿Estás seguro que quieres eliminar Javascript bloque de Publicidad?";

$language['LANG_JSADVERTISEMENT_CREATE_TITLE'] = "Javascript Publicidad crear nuevo bloque";
$language['LANG_JSADVERTISEMENT_EDIT_TITLE'] = "Javascript Anuncio editar bloque";
$language['LANG_JSADVERTISEMENT_DELETE_TITLE'] = "Javascript Publicidad eliminar bloque";
$language['LANG_JSADVERTISEMENT_SETTINGS_MENU'] = "JS Publicidad configuración";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_1'] = "Javascript Publicidad bloque";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_2'] = "se ha creado correctamente!";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_1'] = "Javascript Publicidad bloque";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_2'] = "se salvó con éxito!";
$language['LANG_JSADVERTISEMENT_DELETE_SUCCESS'] = "Javascript bloque de Publicidad se ha eliminado con éxito!";
?>