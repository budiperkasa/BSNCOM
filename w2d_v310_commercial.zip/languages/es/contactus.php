<?php

$language['LANG_CONTACTUS_LINK'] = "Contáctenos";
$language['LANG_CONTACT_US_TITLE'] = "Contáctenos";
$language['LANG_CONTACTUS_NAME'] = "Su nombre";
$language['LANG_CONTACTUS_EMAIL'] = "Su correo electrónico";
$language['LANG_CONTACTUS_SUBJECT'] = "Título del mensaje";
$language['LANG_CONTACTUS_BODY'] = "Cuerpo del mensaje";
$language['LANG_CONTACTUS_SEND_BUTTON'] = "Enviar";

$language['LANG_CONTACTUS_SUCCESS'] = "Mensaje fue enviado con éxito!";
$language['LANG_ENABLE_CONTACTUS_PAGE'] = "Habilitar la página de contacto";
?>