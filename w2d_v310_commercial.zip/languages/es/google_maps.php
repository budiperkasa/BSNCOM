<?php

$language['LANG_MAP'] = "Google Map";
$language['LANG_MAPS_SIGNUP'] = "<a href='http://code.google.com/apis/maps/signup.html' target='_blank'>Regístrate</a> para una clave de API de Google Maps";
$language['LANG_MAPS_KEY'] = "Google Maps API clave";

$language['LANG_BUTTON_MAP'] = "Generar el mapa de google";
$language['LANG_ENTER_LTLG_MANUALLY'] = "Introducir manualmente Latitud / Longitud";
$language['LANG_HIDE_LTLG_MANUALLY'] = "Codificación geográfica Latitud / Longitud de la dirección";
$language['LANG_MAP_LATITUDE'] = "Google Latitude mapa";
$language['LANG_MAP_LONGITUDE'] = "Google longitud mapa";
$language['LANG_MAP_POINT_ADDRESS'] = "mapa de Google punto de dirección";
$language['LANG_MAP_ZOOM_LEVEL'] = "mapa de Google nivel de zoom";

$language['LANG_SELECT_ICON_LISTING'] = "Seleccione el icono y guardar lista";
$language['LANG_SELECT_ICON_LISTING_NOTE'] = "NOTA: juego de iconos depende de las categorías seleccionadas";
$language['LANG_RESET_ICON'] = "Restablecer icono";
$language['LANG_BUTTON_MARKER_ICON'] = "Seleccione el icono del marcador";
$language['LANG_MAP_ICON_ID'] = "Mapa marcador icono de identificación";
$language['LANG_MAP_ICON_FILE'] = "Mapa marcador icono de archivo";
?>