<?php

$language['LANG_FACEBOOK_LOGIN_BTN'] = "Facebook Login";
$language['LANG_FACEBOOK_SETTINGS'] = "Configuración de Facebook";
$language['LANG_FACEBOOK_API_KEY'] = "Facebook clave de API";
$language['LANG_FACEBOOK_APP_ID'] = "Facebook Application ID";
$language['LANG_FACEBOOK_API_KEY_SIGNUP'] = "<a href='http://www.facebook.com/developers/createapp.php' target='_blank'>Registro</a> de su aplicación de Facebook";
$language['LANG_FACEBOOK_APP_SECRET'] = "Aplicación de Facebook Secreto palabra";
?>