<?php

$language['LANG_CALENDAR_SETTINGS_MENU'] = "Ajustes de la Agenda flash";
$language['LANG_CALENDAR_SETTINGS_TITLE'] = "Ajustes de la Agenda flash";
$language['LANG_CALENDAR_NAME'] = "Calendario nombre del widget";
$language['LANG_CALENDAR_ANY_TYPE'] = "Cualquier tipo";
$language['LANG_CALENDAR_TYPE'] = "Conectado tipo";
$language['LANG_CALENDAR_FIELD'] = "Conectado campo de contenido";
$language['LANG_CALENDAR_SEARCH_BY_CREATION_DATE'] = "Fecha de creación";
$language['LANG_CALENDAR_VISIBILITY_INDEX'] = "Widget visible en la página de inicio";
$language['LANG_VISIBILE'] = "visibles";
$language['LANG_NOT_VISIBILE'] = "no visible";
$language['LANG_CALENDAR_VISIBILITY_FOR_TYPES'] = "visibles para los tipos de Widget";
$language['LANG_CALENDAR_VISIBILITY_FOR_ALL_TYPES'] = "para cualquier tipo";
$language['LANG_CALENDAR_VISIBILITY_FOR_CONNECTED_TYPE'] = "sólo para el tipo relacionada";
$language['LANG_CALENDAR_SAVE_SUCCESS'] = "Configuración del calendario se han guardado con éxito!";
?>