<?php
	
	

$language['LANG_SEND_EMAIL_MESSAGE_TITLE'] = "Enviar mensaje de correo electrónico";
$language['LANG_MESSAGE_FROM'] = "Mensaje del";
$language['LANG_YOUR_NAME'] = "Su nombre";
$language['LANG_YOUR_EMAIL'] = "Su correo electrónico";
$language['LANG_MESSAGE_TO'] = "Mensaje para";
$language['LANG_RECIPIENT_NAME'] = "Nombre del destinatario";
$language['LANG_RECIPIENT_EMAIL'] = "Destinatario del correo electrónico";
$language['LANG_SEND_SUCCESS'] = "mensaje de correo electrónico fue enviado con éxito!";
$language['LANG_SUBJECT'] = "Asunto";
$language['LANG_MESSAGE'] = "Mensaje";
$language['LANG_FILL_CAPTCHA'] = "Rellene el texto de seguridad";
$language['LANG_BUTTON_SEND'] = "Enviar";
$language['LANG_BUTTON_CLOSE'] = "Cerrar";
$language['LANG_CAPTCHA'] = "Captcha campo";

$language['LANG_EMAIL_FRIEND_SUBJ'] = "Aquí hay información sobre";
$language['LANG_EMAIL_OWNER_SUBJ'] = "De acuerdo con datos de tu empresa";
$language['LANG_EMAIL_REPORT_SUBJ'] = "Informe sobre la lista";
?>