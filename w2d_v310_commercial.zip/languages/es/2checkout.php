<?php

$language['LANG_2CHECKOUT_REDIRECT_TITLE'] = "Usted será redirigido a 2Checkout";
$language['LANG_2CHECKOUT_REDIRECT_MANUAL'] = "Si usted no es redirigido automáticamente a 2Checkout en 5 segundos ...";
$language['LANG_2CHECKOUT_SID'] = "2CheckOut sid";
$language['LANG_2CHECKOUT_SWORD'] = "2CheckOut palabra secreta";
$language['LANG_2CHECKOUT_SWORD_DESCR'] = "Entrar en su cuenta 2checkout.com y vaya a &#39;Look and Feel&#39; sección. En la parte inferior introducir la palabra secreta y utilizarla en el proceso de verificación de IPN.";
$language['LANG_2CHECKOUT_SETTINGS'] = "2CheckOut configuración";
?>