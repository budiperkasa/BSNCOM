<?php

$language['LANG_CONTACTUS_LINK'] = "Bize ulaşın";
$language['LANG_CONTACT_US_TITLE'] = "Bize ulaşın";
$language['LANG_CONTACTUS_NAME'] = "Adınızı";
$language['LANG_CONTACTUS_EMAIL'] = "E-posta";
$language['LANG_CONTACTUS_SUBJECT'] = "Mesaj Konusu";
$language['LANG_CONTACTUS_BODY'] = "İleti gövdesi";
$language['LANG_CONTACTUS_SEND_BUTTON'] = "Göndermek";

$language['LANG_CONTACTUS_SUCCESS'] = "başarıyla gönderildi Mesaj!";
$language['LANG_ENABLE_CONTACTUS_PAGE'] = "Bize sayfa etkinleştir";
?>