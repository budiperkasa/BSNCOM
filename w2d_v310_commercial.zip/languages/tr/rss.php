<?php

$language['LANG_RSS_FEED_RECENT_LISTINGS'] = "Son listeleri Feed";
$language['LANG_RSS_FEED_TYPE_LISTINGS'] = "Bu tür listeleri Feed";
$language['LANG_RSS_FEED_CATEGORIES_LISTINGS'] = "Bu kategoride listelerini Feed";
$language['LANG_RSS_FEED_SEARCH_LISTINGS'] = "Bu arama sonuçları listeleri Feed";
$language['LANG_RSS_FEED_IN_LOCATION'] = "bir yerde";
?>