<?php

$language['LANG_JSADVERTISEMENT_MANAGE_BLOCKS_TITLE'] = "Javascript Reklam blokları yönet";
$language['LANG_JSADVERTISEMENT_ALL_BLOCKS'] = "Javascript Reklam blokları yönet";
$language['LANG_CREATE_JSADVERTISEMENT_BLOCK'] = "yeni js reklam blok oluşturmak";
$language['LANG_EDIT_JSADVERTISEMENT_BLOCK'] = "js reklam blok düzenleme";
$language['LANG_CREATE_JSADVERTISEMENT'] = "yeni reklam blok oluşturma";
$language['LANG_EDIT_JSADVERTISEMENT'] = "js reklam engelleme Düzenle";
$language['LANG_DELETE_JSADVERTISEMENT_BLOCK'] = "js reklam bloğu silmek";
$language['LANG_JSADVERTISEMENT_BLOCK_NAME_TH'] = "Blok adı";
$language['LANG_JSADVERTISEMENT_BLOCK_MODE_TH'] = "Görünüm modunu";
$language['LANG_JSADVERTISEMENT_BLOCK_SELECTOR_TH'] = "Seçici";
$language['LANG_JSADVERTISEMENT_CODE'] = "Javascript Reklam kodu";
$language['LANG_BUTTON_CREATE_JSADVERTISEMENT'] = "Oluşturmak reklam blok js";
$language['LANG_DELETE_JSADVERTISEMENT'] = "Silmek js reklam blok";
$language['LANG_DELETE_JSADVERTISEMENT_QUEST'] = "görebilmek için Javascript Reklam bloğu silmek istiyor musun?";

$language['LANG_JSADVERTISEMENT_CREATE_TITLE'] = "Javascript Anons yeni bir blok oluşturmak";
$language['LANG_JSADVERTISEMENT_EDIT_TITLE'] = "Javascript Reklam blok düzenleme";
$language['LANG_JSADVERTISEMENT_DELETE_TITLE'] = "Javascript Reklam bloğu silmek";
$language['LANG_JSADVERTISEMENT_SETTINGS_MENU'] = "JS Reklam ayarları";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_1'] = "Javascript Reklam blok";
$language['LANG_NEW_JSADVERTISEMENT_CREATE_SUCCESS_2'] = "başarıyla oluşturuldu!";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_1'] = "Javascript Reklam blok";
$language['LANG_JSADVERTISEMENT_SAVE_SUCCESS_2'] = "başarılı bir şekilde kurtarıldı!";
$language['LANG_JSADVERTISEMENT_DELETE_SUCCESS'] = "Javascript Anons blok başarıyla silindi!";
?>