<?php
	
/**
 * Images upload block
 */
$language['LANG_MAX_IMAGE_SIZE'] = "Maksimum görüntü boyutu";
$language['LANG_MAX_FILE_SIZE'] = "maksimum dosya boyutu";
$language['LANG_NEW_FILE_TITLE'] = "Yeni bir dosya başlığı";
$language['LANG_SYMBOLS_MAX'] = "semboller max";
$language['LANG_BUTTON_UPLOAD_FILE'] = "Dosya yükleme";
$language['LANG_UPLOAD_FILE'] = "Upload yeni dosya";
$language['LANG_UPLOAD_IMAGE'] = "Upload yeni görüntü";
$language['LANG_SUPPORTED_FORMAT'] = "Desteklenen formatlar";
$language['LANG_BUTTON_UPLOAD_IMAGE'] = "Upload görüntü";
$language['LANG_CROP_IMAGE'] = "Ürün görüntü";
?>