<?php
	

$language['LANG_PAYPAL_SETTINGS'] = "PayPal ayarları";
$language['LANG_PAYPAL_REDIRECT_TITLE'] = "PayPal yönlendirileceksiniz";
$language['LANG_PAYPAL_REDIRECT_MANUAL'] = "otomatik olarak 5 saniye içinde PayPal yönlendiriliyorsunuz değilseniz ...";
$language['LANG_PAYPAL_EMAIL'] = "PayPal İşletme E-posta";
?>