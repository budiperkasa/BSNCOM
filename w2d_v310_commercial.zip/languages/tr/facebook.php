<?php

$language['LANG_FACEBOOK_LOGIN_BTN'] = "Facebook Giriş";
$language['LANG_FACEBOOK_SETTINGS'] = "Facebook Ayarlar";
$language['LANG_FACEBOOK_API_KEY'] = "Facebook API Anahtarı";
$language['LANG_FACEBOOK_APP_ID'] = "Facebook Application ID";
$language['LANG_FACEBOOK_API_KEY_SIGNUP'] = "<a href='http://www.facebook.com/developers/createapp.php' target='_blank'>Kayıt</a> için Facebook Uygulaması";
$language['LANG_FACEBOOK_APP_SECRET'] = "Facebook Uygulaması Gizli kelime";
?>