<?php

$language['LANG_EMAIL_NOTIFICATIONS'] = "E-posta bildirimi Düzenle";
$language['LANG_NOTIFICATION_RAISE'] = "Bildirimini yükseltir";
$language['LANG_NOTIFICATION_SUBJECT'] = "Bildirim konusu";
$language['LANG_NOTIFICATION_BODY'] = "Bildirim vücut";
$language['LANG_VIEW_EMAIL_NOTIFICATIONS'] = "Görünüm e-posta bildirimleri";
$language['LANG_EDIT_NOTIFICATION_OPTION'] = "bildirim düzenleme";
// Controller constants
$language['LANG_VIEW_EMAIL_NOTIFICATIONS_TITLE'] = "Görünüm e-posta bildirimleri";
$language['LANG_EDIT_EMAIL_NOTIFICATIONS_TITLE'] = "e-posta bildirimleri Düzenle";
$language['LANG_EMAIL_NOTIFICATIONS_MENU'] = "E-posta bildirimleri";
$language['LANG_NOTIFICATION_SEND_SUCCESS_1'] = "olay Bildirim";
$language['LANG_NOTIFICATION_SEND_SUCCESS_2'] = "başarılı bir şekilde kurtarıldı!";
?>