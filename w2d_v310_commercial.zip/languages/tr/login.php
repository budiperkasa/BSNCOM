<?php
	
	
/**
 * Authorization page
 */
$language['LANG_AUTHORIZATION_MENU'] = "Yetki";
$language['LANG_USER_EMAIL'] = "E-posta";
$language['LANG_USER_PASSWORD'] = "Kullanıcı Şifre";
$language['LANG_USER_LOGIN_ERROR'] = "E-posta veya şifre hatalı!";
$language['LANG_USER_BLOCKED'] = "Bu e-posta ile kullanıcı admin tarafından engellendi!";
/**
 * Login page, login block
 */
$language['LANG_LOGIN_HEADER'] = "Giriş";
$language['LANG_LOGIN_EMAIL'] = "E-posta";
$language['LANG_LOGIN_PASSWORD'] = "Şifre";
$language['LANG_BUTTON_LOGIN'] = "Giriş";
$language['LANG_CREATE_ACCOUNT'] = "bir hesap oluşturun";
$language['LANG_FORGOT_PASS'] = "Şifremi unuttum?";
$language['LANG_REMEMBER_ME'] = "Beni hatırla";
?>