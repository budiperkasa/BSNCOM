<?php
	
	

$language['LANG_SEND_EMAIL_MESSAGE_TITLE'] = "E-posta mesajı gönder";
$language['LANG_MESSAGE_FROM'] = "Mesajı";
$language['LANG_YOUR_NAME'] = "Adınızı";
$language['LANG_YOUR_EMAIL'] = "E-posta";
$language['LANG_MESSAGE_TO'] = "Mesaj";
$language['LANG_RECIPIENT_NAME'] = "Alıcı adı";
$language['LANG_RECIPIENT_EMAIL'] = "Alıcının e-posta";
$language['LANG_SEND_SUCCESS'] = "E-posta mesajı göndermek başarılı oldu!";
$language['LANG_SUBJECT'] = "Konu";
$language['LANG_MESSAGE'] = "Mesajı";
$language['LANG_FILL_CAPTCHA'] = "Doldurmak güvenlik metin";
$language['LANG_BUTTON_SEND'] = "Göndermek";
$language['LANG_BUTTON_CLOSE'] = "Yakın";
$language['LANG_CAPTCHA'] = "Captcha alan";

$language['LANG_EMAIL_FRIEND_SUBJ'] = "Burada bilgi üzerinde";
$language['LANG_EMAIL_OWNER_SUBJ'] = "Listenizi göre";
$language['LANG_EMAIL_REPORT_SUBJ'] = "Rapor hakkında listeleme";
?>