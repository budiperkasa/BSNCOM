<?php

$language['LANG_ALERTPAY_SETTINGS'] = "AlertPay ayarları";
$language['LANG_ALERTPAY_REDIRECT_TITLE'] = "AlertPay için yönlendirilmiş olacaktır";
$language['LANG_ALERTPAY_REDIRECT_MANUAL'] = "5 saniye içinde otomatik olarak AlertPay yönlendirilmez iseniz ...";
$language['LANG_ALERTPAY_EMAIL'] = "AlertPay E-posta";
$language['LANG_ALERTPAY_SECURITYCODE'] = "AlertPay Güvenlik kodu."
$language['LANG_ALERTPAY_SECURITYCODE_DESCR'] = "IPN aldı AlertPay geldiğini onaylamak için kullanılır olmalı AlertPay hesabınıza IPN Güvenlik Kodu karşılaştırın."
?>