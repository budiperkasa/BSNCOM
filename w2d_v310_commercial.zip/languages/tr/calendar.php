<?php

$language['LANG_CALENDAR_SETTINGS_MENU'] = "Takvim widget ayarları";
$language['LANG_CALENDAR_SETTINGS_TITLE'] = "Takvim widget ayarları";
$language['LANG_CALENDAR_NAME'] = "Takvim ismiyle";
$language['LANG_CALENDAR_ANY_TYPE'] = "Her türlü";
$language['LANG_CALENDAR_TYPE'] = "türü Bağlı";
$language['LANG_CALENDAR_FIELD'] = "içerik alan Bağlı";
$language['LANG_CALENDAR_SEARCH_BY_CREATION_DATE'] = "Oluşturulma tarihi";
$language['LANG_CALENDAR_VISIBILITY_INDEX'] = "Widget ana sayfada görünür";
$language['LANG_VISIBILE'] = "görünür";
$language['LANG_NOT_VISIBILE'] = "görünür değil";
$language['LANG_CALENDAR_VISIBILITY_FOR_TYPES'] = "Widget türleri görebilir";
$language['LANG_CALENDAR_VISIBILITY_FOR_ALL_TYPES'] = "herhangi bir türü için";
$language['LANG_CALENDAR_VISIBILITY_FOR_CONNECTED_TYPE'] = "bağlı türü sadece";
$language['LANG_CALENDAR_SAVE_SUCCESS'] = "Takvim ayarları başarıyla kaydedildi!";
?>