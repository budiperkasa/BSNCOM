<?php

$language['LANG_2CHECKOUT_REDIRECT_TITLE'] = "Eğer 2Checkout yönlendirileceksiniz";
$language['LANG_2CHECKOUT_REDIRECT_MANUAL'] = "otomatik olarak 5 saniye içinde 2Checkout yönlendiriliyorsunuz değilseniz ...";
$language['LANG_2CHECKOUT_SID'] = "2checkout sid";
$language['LANG_2CHECKOUT_SWORD'] = "2checkout gizli kelime";
$language['LANG_2CHECKOUT_SWORD_DESCR'] = "Giriş 2checkout.com dikkate ve &#39;Bak ve Hisset&#39; için bölümüne gidin. alt kısmında Gizli Söz girin ve IPN doğrulama işlemini kullanabilirsiniz.";
$language['LANG_2CHECKOUT_SETTINGS'] = "2checkout ayarları";
?>