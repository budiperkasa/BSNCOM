<?php

$language['LANG_MAP'] = "Google Map";
$language['LANG_MAPS_SIGNUP'] = "<a href='http://code.google.com/apis/maps/signup.html' target='_blank'>Facebook&#39;a kaydol</a> Haritalar için bir Google Api Key";
$language['LANG_MAPS_KEY'] = "Google Maps API anahtarı";

$language['LANG_BUTTON_MAP'] = "google harita üzerinde Oluştur";
$language['LANG_ENTER_LTLG_MANUALLY'] = "el Enlem / Boylam girin";
$language['LANG_HIDE_LTLG_MANUALLY'] = "Coğrafi kod Enlem / Boylam adresi";
$language['LANG_MAP_LATITUDE'] = "Google harita enlem";
$language['LANG_MAP_LONGITUDE'] = "Google harita boylam";
$language['LANG_MAP_POINT_ADDRESS'] = "Google harita noktası adresi";
$language['LANG_MAP_ZOOM_LEVEL'] = "Google harita yakınlaştırma seviyesini";

$language['LANG_SELECT_ICON_LISTING'] = "Seçmek simgesi ve listeleme kaydetmek";
$language['LANG_SELECT_ICON_LISTING_NOTE'] = "NOT: Simgeler set seçilen kategoriye bağlıdır";
$language['LANG_RESET_ICON'] = "Sıfırlama simge";
$language['LANG_BUTTON_MARKER_ICON'] = "Seçmek işaretleyici simgesi";
$language['LANG_MAP_ICON_ID'] = "Harita işaretleyici simgesi Kimliği";
$language['LANG_MAP_ICON_FILE'] = "Harita işaretleyici simgesi dosya";
?>